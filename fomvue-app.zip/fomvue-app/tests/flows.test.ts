import { describe, it, expect, beforeAll } from "vitest";
import { prisma } from "@/lib/db";
import { signup, verifyCredentials, createSession, userFromToken, UserError } from "@/lib/services/auth";
import { createProduct, createFilm, hasFilmAccess, ownsProduct } from "@/lib/services/catalog";
import { startCheckout, applyPaymentEvent, handleWebhook } from "@/lib/services/payments";
import { shopBalance, requestPayout, processPayout, platformRevenue } from "@/lib/services/ledger";
import { signMock } from "@/lib/payments/mock";

let creatorId = "", shopId = "", buyerId = "", productId = "", filmId = "";

async function confirm(paymentId: string, status: "SUCCEEDED" | "FAILED" = "SUCCEEDED") {
  const p = await prisma.payment.findUniqueOrThrow({ where: { id: paymentId } });
  const body = JSON.stringify({ reference: p.reference, status });
  return handleWebhook("mock", body, new Headers({ "x-mock-signature": signMock(body) }));
}

describe("Fomvue — parcours principaux", () => {
  beforeAll(async () => {
    const c = await signup({ name: "Awa Test", email: "awa@test.sn", password: "motdepasse", asCreator: true, shopName: "Studio Awa" });
    creatorId = c.id;
    shopId = (await prisma.shop.findUniqueOrThrow({ where: { ownerId: c.id } })).id;
    buyerId = (await signup({ name: "Moussa", email: "moussa@test.sn", password: "motdepasse" })).id;
  });

  it("inscription : mot de passe haché, boutique créée, session valide", async () => {
    const u = await prisma.user.findUniqueOrThrow({ where: { id: creatorId }, include: { shop: true } });
    expect(u.passwordHash).not.toContain("motdepasse");
    expect(u.role).toBe("CREATOR");
    expect(u.shop?.slug).toBe("studio-awa");
    await expect(signup({ name: "Xavier", email: "awa@test.sn", password: "motdepasse" })).rejects.toBeInstanceOf(UserError);
    await expect(verifyCredentials("awa@test.sn", "mauvais")).rejects.toBeInstanceOf(UserError);
    const s = await createSession((await verifyCredentials("AWA@test.sn", "motdepasse")).id);
    expect((await userFromToken(s.token))?.id).toBe(creatorId);
    expect(await userFromToken("faux")).toBeNull();
  });

  it("création de produit", async () => {
    const p = await createProduct(shopId, { title: "Pack prompts", category: "PROMPTS", kind: "PROMPTS", description: "Trente prompts testés.", price: 5000 });
    productId = p.id;
    expect(p.slug).toBe("pack-prompts");
    await expect(createProduct(shopId, { title: "X", category: "PROMPTS", kind: "PROMPTS", description: "court", price: 10 })).rejects.toThrow();
  });

  it("achat (mock) : commande + commission 10 % + solde créateur, idempotent", async () => {
    const { paymentId, redirectUrl } = await startCheckout({ purpose: "ORDER", productId, userId: buyerId, method: "wave", phone: "771112233" });
    expect(redirectUrl).toBe(`/paiement/test/${paymentId}`);
    expect(await ownsProduct(buyerId, productId)).toBe(false);
    const r = await confirm(paymentId);
    expect(r.ok).toBe(true);
    const order = await prisma.order.findUniqueOrThrow({ where: { paymentId } });
    expect(order.commission).toBe(500);
    expect(order.creatorNet).toBe(4500);
    expect(await ownsProduct(buyerId, productId)).toBe(true);
    expect(await shopBalance(shopId)).toBe(4500);
    // rejouer le webhook ne crée rien de plus
    await confirm(paymentId);
    expect(await prisma.order.count({ where: { productId } })).toBe(1);
    expect(await shopBalance(shopId)).toBe(4500);
    // ré-achat bloqué
    await expect(startCheckout({ purpose: "ORDER", productId, userId: buyerId, method: "wave" })).rejects.toBeInstanceOf(UserError);
  });

  it("webhook à signature invalide refusé ; paiement échoué sans effet", async () => {
    const bad = await handleWebhook("mock", JSON.stringify({ reference: "x", status: "SUCCEEDED" }), new Headers({ "x-mock-signature": "faux" }));
    expect(bad.ok).toBe(false);
    const p2 = await createProduct(shopId, { title: "Ebook", category: "IDEES", kind: "EBOOK", description: "Un ebook de démonstration.", price: 3000 });
    const { paymentId } = await startCheckout({ purpose: "ORDER", productId: p2.id, userId: buyerId, method: "orange" });
    await confirm(paymentId, "FAILED");
    expect(await prisma.order.count({ where: { productId: p2.id } })).toBe(0);
    expect((await prisma.payment.findUniqueOrThrow({ where: { id: paymentId } })).status).toBe("FAILED");
  });

  it("soutien (tip) : commission 5 %", async () => {
    const { paymentId } = await startCheckout({ purpose: "TIP", shopId, amount: 2000, message: "Bravo", senderName: "Fan", userId: null, method: "wave" });
    await confirm(paymentId);
    const tip = await prisma.tip.findUniqueOrThrow({ where: { paymentId } });
    expect(tip.commission).toBe(100);
    expect(tip.creatorNet).toBe(1900);
    expect(await shopBalance(shopId)).toBe(4500 + 1900);
    await expect(startCheckout({ purpose: "TIP", shopId, amount: 50, userId: null, method: "wave" })).rejects.toBeInstanceOf(UserError);
  });

  it("film payant : achat et location 48 h", async () => {
    const f = await createFilm(shopId, { title: "Nuit sur la Corniche", kind: "SERIE", synopsis: "Une série urbaine à Dakar.", videoUrl: "https://youtu.be/aqz-KE-bpKQ", access: "PAID", buyPrice: 3000, rentPrice: 1000 });
    filmId = f.id;
    expect(await hasFilmAccess(buyerId, f)).toBe(false);
    const rent = await startCheckout({ purpose: "FILM", filmId, mode: "RENT", userId: buyerId, method: "mtn" });
    await confirm(rent.paymentId);
    const acc = await prisma.filmAccess.findUniqueOrThrow({ where: { paymentId: rent.paymentId } });
    expect(acc.expiresAt!.getTime() - Date.now()).toBeGreaterThan(47 * 3600e3);
    expect(await hasFilmAccess(buyerId, f)).toBe(true);
    // location expirée -> plus d'accès
    await prisma.filmAccess.update({ where: { id: acc.id }, data: { expiresAt: new Date(Date.now() - 1000) } });
    expect(await hasFilmAccess(buyerId, f)).toBe(false);
    const buy = await startCheckout({ purpose: "FILM", filmId, mode: "BUY", userId: buyerId, method: "wave" });
    await confirm(buy.paymentId);
    expect(await hasFilmAccess(buyerId, f)).toBe(true);
    expect(await shopBalance(shopId)).toBe(4500 + 1900 + 900 + 2700);
    const free = await createFilm(shopId, { title: "Café Téranga", kind: "TALKSHOW", synopsis: "Talk-show gratuit du matin.", videoUrl: "https://youtu.be/aqz-KE-bpKQ", access: "FREE" });
    expect(await hasFilmAccess(null, free)).toBe(true);
  });

  it("retraits : minimum, solde, refus = recrédit ; revenus plateforme", async () => {
    await expect(requestPayout(shopId, 1000, "wave", "771112233")).rejects.toBeInstanceOf(UserError);
    await expect(requestPayout(shopId, 999999, "wave", "771112233")).rejects.toBeInstanceOf(UserError);
    const p = await requestPayout(shopId, 5000, "wave", "771112233");
    expect(await shopBalance(shopId)).toBe(10000 - 5000);
    await processPayout(p.id, "REJECTED");
    expect(await shopBalance(shopId)).toBe(10000);
    const p2 = await requestPayout(shopId, 6000, "orange", "771112233");
    await processPayout(p2.id, "PAID");
    expect(await shopBalance(shopId)).toBe(4000);
    const rev = await platformRevenue();
    expect(rev).toEqual({ sales: 500, films: 100 + 300, tips: 100, total: 1000 });
  });

  it("applyPaymentEvent ignore une référence inconnue", async () => {
    expect((await applyPaymentEvent({ reference: "nope", status: "SUCCEEDED", raw: "" })).applied).toBe(false);
  });
});

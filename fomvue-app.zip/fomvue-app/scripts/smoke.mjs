/**
 * Test de bout en bout (navigateur réel) + captures d'écran.
 * Prérequis : serveur lancé (npm start) et base seedée (npm run db:seed).
 * Usage : BASE_URL=http://localhost:3000 node scripts/smoke.mjs   (SCREENS=0 pour ne pas capturer)
 */
import { chromium } from "playwright";
import fs from "node:fs";

const BASE = process.env.BASE_URL || "http://localhost:3000";
const SHOTS = process.env.SCREENS !== "0";
const OUT = new URL("../screens/", import.meta.url).pathname;
fs.mkdirSync(OUT, { recursive: true });

const exe = ["/usr/bin/google-chrome", "/usr/bin/chromium"].find((p) => fs.existsSync(p));
const browser = await chromium.launch(exe ? { executablePath: exe } : {});
const results = [];
const step = async (name, fn) => {
  try {
    await fn();
    results.push(["OK", name]);
    console.log("✓", name);
  } catch (e) {
    results.push(["ÉCHEC", name]);
    console.error("✗", name, "\n ", e.message.split("\n")[0]);
  }
};
const shot = async (page, name, full = false) => {
  if (!SHOTS) return;
  await page.waitForLoadState("networkidle").catch(() => {});
  await page.waitForTimeout(300);
  await page.screenshot({ path: `${OUT}fomvue-${name}.png`, fullPage: full });
};
const expectText = async (page, text) => {
  await page.locator("main").getByText(text, { exact: false }).first().waitFor({ timeout: 8000 });
};

const ctx = await browser.newContext({ viewport: { width: 1366, height: 860 }, locale: "fr-FR" });
const page = await ctx.newPage();
const stamp = Date.now().toString(36);

// ---------- Pages publiques ----------
await step("Accueil", async () => {
  await page.goto(BASE + "/");
  await expectText(page, "Vos créations IA.");
  await expectText(page, "Regarder • Apprendre • Créer");
  await shot(page, "01-accueil");
  await shot(page, "01b-accueil-complet", true);
});
await step("Regarder", async () => {
  await page.goto(BASE + "/regarder");
  await expectText(page, "À la une");
  await shot(page, "02-regarder");
});
await step("Boutique créateur", async () => {
  await page.goto(BASE + "/boutique/awa-diop");
  await expectText(page, "awa-diop.fomvue.com");
  await shot(page, "03-boutique");
});
await step("Catalogue", async () => {
  await page.goto(BASE + "/catalogue?cat=scenarios");
  await expectText(page, "Scénarios & séries");
  await shot(page, "04-catalogue");
});

// ---------- Inscription créateur + création de produit ----------
const creatorEmail = `createur-${stamp}@test.sn`;
let productUrl = "";
await step("Inscription d'un créateur", async () => {
  await page.goto(BASE + "/inscription?createur=1");
  await page.fill("#name", "Khady Test");
  await page.fill("#email", creatorEmail);
  await page.fill("#password", "motdepasse123");
  await page.fill("#shopName", `Studio Khady ${stamp}`);
  await page.click("main button[type=submit]");
  await page.waitForURL("**/vendeur**");
  await expectText(page, "Espace vendeur");
});
await step("Création d'un produit", async () => {
  await page.goto(BASE + "/vendeur/produits/nouveau");
  await page.fill("#title", "Pack 30 prompts pubs Wave & Orange");
  await page.selectOption("#category", "PROMPTS");
  await page.selectOption("#kind", "PROMPTS");
  await page.fill("#price", "4500");
  await page.fill("#description", "Trente prompts testés pour créer des pubs IA de commerçants dakarois.");
  await page.fill("#includes", "30 prompts\nGuide PDF");
  await page.setInputFiles("#file", { name: "prompts.txt", mimeType: "text/plain", buffer: Buffer.from("Prompt 1 : marché Sandaga au lever du soleil…") });
  await page.click("button:has-text('Publier le produit')");
  await page.waitForURL("**/vendeur/produits?ok=**");
  await expectText(page, "Pack 30 prompts pubs");
  await shot(page, "09-vendeur-produits");
  productUrl = await page.locator("a:has-text('Pack 30 prompts pubs')").first().getAttribute("href");
});
await step("Publication d'un film payant", async () => {
  await page.goto(BASE + "/vendeur/films");
  await page.fill("#title", `Film test ${stamp}`);
  await page.fill("#synopsis", "Un court métrage IA tourné entre Dakar et Saint-Louis.");
  await page.fill("#videoUrl", "https://www.youtube.com/watch?v=aqz-KE-bpKQ");
  await page.check("input[name=access][value=PAID]");
  await page.fill("#buyPrice", "2000");
  await page.click("button:has-text('Publier dans Regarder')");
  await page.waitForURL("**/vendeur/films?ok=**");
  await expectText(page, `Film test ${stamp}`);
});
await page.context().clearCookies();

// ---------- Acheteur : achat produit (mock), soutien, film ----------
const buyerCtx = await browser.newContext({ viewport: { width: 1366, height: 860 }, locale: "fr-FR" });
const b = await buyerCtx.newPage();
await step("Inscription d'un acheteur", async () => {
  await b.goto(BASE + "/inscription");
  await b.fill("#name", "Ousmane Acheteur");
  await b.fill("#email", `acheteur-${stamp}@test.sn`);
  await b.fill("#password", "motdepasse123");
  await b.click("main button[type=submit]");
  await b.waitForURL(BASE + "/");
});
await step("Achat d'un produit (paiement test)", async () => {
  await b.goto(BASE + productUrl);
  await shot(b, "05-produit");
  await b.click("[data-testid=buy-btn]");
  await b.waitForURL("**/checkout/**");
  await b.fill("#phone", "77 111 22 33");
  await shot(b, "06-checkout");
  await b.click("[data-testid=pay-btn]");
  await b.waitForURL("**/paiement/test/**");
  await shot(b, "07-paiement-test");
  await b.click("[data-testid=mock-confirm]");
  await b.waitForURL("**/paiement/retour/**");
  await expectText(b, "Paiement confirmé");
  await shot(b, "08-paiement-confirme");
  await b.goto(BASE + "/mes-achats");
  await expectText(b, "Pack 30 prompts pubs");
  const res = await b.request.get(BASE + "/api/download/" + productUrl.split("/").pop());
  if (res.status() !== 200 || !(await res.text()).includes("Sandaga")) throw new Error("téléchargement KO");
});
await step("Soutien à un créateur (2 000 F CFA)", async () => {
  await b.goto(BASE + "/boutique/awa-diop");
  await b.click("[data-testid=support-btn]");
  await b.click(".amount-pick:has-text('2')");
  await b.fill("#message", "Merci pour Café Téranga !");
  await b.fill("#phone", "77 111 22 33");
  await shot(b, "10-soutien-modal");
  await b.click("button:has-text('Envoyer 2')");
  await b.waitForURL("**/paiement/test/**");
  await b.click("[data-testid=mock-confirm]");
  await expectText(b, "Merci pour votre soutien");
  await b.goto(BASE + "/boutique/awa-diop");
  await expectText(b, "Merci pour Café Téranga !");
});
await step("Achat d'un film payant", async () => {
  await b.goto(BASE + "/regarder");
  await b.locator(".title-card", { hasText: `Film test ${stamp}` }).first().click();
  await b.waitForURL(/\/regarder\/[^/]+$/);
  await shot(b, "11-film-fiche");
  await b.goto(b.url() + "/voir");
  await expectText(b, "Ce titre est payant");
  await shot(b, "12-film-paywall");
  await b.click("a:has-text('Acheter ·')");
  await b.fill("#phone", "77 111 22 33");
  await b.click("[data-testid=pay-btn]");
  await b.click("[data-testid=mock-confirm]");
  await expectText(b, "Titre acheté");
  await b.click("a:has-text('Regarder maintenant')");
  await b.locator(".video-frame iframe, .video-frame video").first().waitFor();
});
await step("Webhook : signature invalide refusée", async () => {
  const r = await b.request.post(BASE + "/api/webhooks/mock", { data: '{"reference":"x","status":"SUCCEEDED"}', headers: { "x-mock-signature": "faux", "content-type": "application/json" } });
  if (r.status() !== 401) throw new Error("attendu 401, reçu " + r.status());
});

// ---------- Créateur : vérifie ses revenus ----------
await step("Tableau de bord créateur (vente + film)", async () => {
  await page.goto(BASE + "/connexion");
  await page.fill("#email", creatorEmail);
  await page.fill("#password", "motdepasse123");
  await page.click("main button[type=submit]");
  await page.waitForURL((u) => !u.pathname.startsWith("/connexion"));
  await page.goto(BASE + "/vendeur");
  // 4 500 - 10 % = 4 050 ; film 2 000 - 10 % = 1 800 ; solde 5 850
  await expectText(page, /5\s850/);
});

// ---------- Démo : comptes seedés ----------
const demo = await browser.newContext({ viewport: { width: 1366, height: 860 }, locale: "fr-FR" });
const d = await demo.newPage();
const login = async (email) => {
  await d.context().clearCookies();
  await d.goto(BASE + "/connexion");
  await d.fill("#email", email);
  await d.fill("#password", "demo1234");
  await d.click("main button[type=submit]");
  await d.waitForURL((u) => !u.pathname.startsWith("/connexion"));
};
await step("Dashboard créatrice démo (Awa)", async () => {
  await login("awa@fomvue.com");
  await d.goto(BASE + "/vendeur");
  await expectText(d, "Solde à retirer");
  await shot(d, "13-dashboard-vendeur", true);
  await d.goto(BASE + "/vendeur/films");
  await shot(d, "14-dashboard-films");
  await d.goto(BASE + "/vendeur/soutiens");
  await shot(d, "15-dashboard-soutiens");
});
await step("Bibliothèque + lecteur de cours (Moussa)", async () => {
  await login("moussa@exemple.sn");
  await d.goto(BASE + "/mes-achats");
  await expectText(d, "Ma bibliothèque");
  await shot(d, "16-mes-achats");
  await d.click("a:has-text('Continuer')");
  await d.waitForURL("**/apprendre/**");
  await shot(d, "17-lecteur-cours");
});
await step("Admin (Gina)", async () => {
  await login("gina@fomvue.com");
  await d.goto(BASE + "/admin");
  await expectText(d, "Commissions Fomvue");
  await shot(d, "18-admin", true);
  await d.goto(BASE + "/admin/produits");
  await shot(d, "19-admin-moderation");
});
await step("Mobile — accueil", async () => {
  const m = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, locale: "fr-FR" });
  const mp = await m.newPage();
  await mp.goto(BASE + "/");
  await shot(mp, "20-mobile-accueil");
  await mp.click(".burger");
  await mp.locator(".drawer a", { hasText: "Regarder" }).waitFor();
  await shot(mp, "21-mobile-menu");
  await m.close();
});

await browser.close();
const failed = results.filter((r) => r[0] !== "OK");
console.log(`\n${results.length - failed.length}/${results.length} étapes OK`);
process.exit(failed.length ? 1 : 0);

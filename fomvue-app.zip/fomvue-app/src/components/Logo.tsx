import Link from "next/link";
import { BRAND, SLOGAN, SLOGAN_EN } from "@/lib/constants";

export function LogoMark() {
  return (
    <span className="logo-mark" aria-hidden="true">
      <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
        <path d="M10 2.2l1.4 5.1L16.8 8l-4.2 3.3L13.8 17 10 13.9 6.2 17l1.2-5.7L3.2 8l5.4-.7L10 2.2z" fill="white" />
      </svg>
    </span>
  );
}

export function Logo() {
  return (
    <Link className="logo" href="/" aria-label="Accueil">
      <LogoMark />
      <span className="logo-text">
        <span className="logo-word">{BRAND}</span>
        <span className="logo-slogan" title={SLOGAN_EN}>{SLOGAN}</span>
      </span>
    </Link>
  );
}

export function CatIcon({ slug }: { slug: string }) {
  const p = { width: 22, height: 22, fill: "none", stroke: "currentColor", strokeWidth: 1.8 } as const;
  switch (slug) {
    case "scenarios":
      return <svg {...p}><rect x="3" y="4" width="16" height="14" rx="2" /><path d="M7 8h8M7 11h5" /></svg>;
    case "idees":
      return <svg {...p}><path d="M11 3a6 6 0 0 1 3.5 10.8V16H7.5v-2.2A6 6 0 0 1 11 3z" /><path d="M8 19h6" /></svg>;
    case "services":
      return <svg {...p}><circle cx="11" cy="8" r="3" /><path d="M4 19c1.2-3 3.5-4.5 7-4.5S16.8 16 18 19" /></svg>;
    case "formations":
      return <svg {...p}><path d="M3 9l8-4 8 4-8 4-8-4z" /><path d="M7 11.5V15c0 0 1.8 2 4 2s4-2 4-2v-3.5" /></svg>;
    default:
      return <svg {...p}><path d="M5 5h12v8H9l-4 3V5z" /></svg>;
  }
}

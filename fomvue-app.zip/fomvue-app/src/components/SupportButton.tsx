"use client";
import { useState } from "react";
import { tipAction } from "@/app/actions/checkout";

const PRESETS = [500, 1000, 2000, 5000];
const METHODS = [
  { id: "wave", label: "Wave", short: "WAVE", bg: "#1dc8f6", fg: "#083344" },
  { id: "orange", label: "Orange Money", short: "OM", bg: "#ff6600", fg: "#fff" },
  { id: "mtn", label: "MTN MoMo", short: "MTN", bg: "#ffcc00", fg: "#1a1a1a" },
  { id: "moov", label: "Moov", short: "MOOV", bg: "#0066b3", fg: "#fff" },
  { id: "carte", label: "Carte", short: "CARTE", bg: "#16141f", fg: "#fff" },
];
const fmt = (n: number) => `${n.toLocaleString("fr-FR")} F CFA`;

export function SupportButton({ shopId, shopName, filmId, back, label = "Soutenir le créateur", userName }: { shopId: string; shopName: string; filmId?: string; back: string; label?: string; userName?: string }) {
  const [open, setOpen] = useState(false);
  const [amount, setAmount] = useState(1000);
  const [custom, setCustom] = useState("");
  const [method, setMethod] = useState("wave");
  const total = parseInt(custom.replace(/\D/g, ""), 10) || amount;
  return (
    <>
      <button type="button" className="btn btn-support" onClick={() => setOpen(true)} data-testid="support-btn">
        ♥ {label}
      </button>
      {open && (
        <div className="modal-backdrop is-open" onClick={(e) => e.target === e.currentTarget && setOpen(false)}>
          <div className="modal" role="dialog" aria-modal="true" aria-labelledby="support-title">
            <button type="button" className="modal-close" aria-label="Fermer" onClick={() => setOpen(false)}>×</button>
            <h2 id="support-title" style={{ fontSize: "1.35rem", paddingRight: 40 }}>Soutenir {shopName}</h2>
            <p className="muted tiny">Un don libre pour encourager le créateur. Fomvue garde 5 %, le reste lui est reversé.</p>
            <form action={tipAction}>
              <input type="hidden" name="shopId" value={shopId} />
              <input type="hidden" name="back" value={back} />
              {filmId && <input type="hidden" name="filmId" value={filmId} />}
              <input type="hidden" name="amount" value={amount} />
              <input type="hidden" name="method" value={method} />
              <div className="support-form-grid">
                <div>
                  <div className="amount-picks">
                    {PRESETS.map((v) => (
                      <button key={v} type="button" className={`amount-pick ${!custom && amount === v ? "is-on" : ""}`} onClick={() => { setAmount(v); setCustom(""); }}>
                        {v.toLocaleString("fr-FR")}
                      </button>
                    ))}
                  </div>
                  <div className="field"><label htmlFor="customAmount">Autre montant (F CFA)</label><input id="customAmount" name="customAmount" inputMode="numeric" value={custom} onChange={(e) => setCustom(e.target.value)} placeholder="Ex. 3 000" /></div>
                  <div className="field"><label htmlFor="senderName">Votre nom (affiché)</label><input id="senderName" name="senderName" defaultValue={userName} placeholder="Anonyme" /></div>
                  <div className="field"><label htmlFor="message">Message (facultatif)</label><textarea id="message" name="message" maxLength={280} placeholder="Bravo pour la série !" /></div>
                </div>
                <div>
                  <div style={{ marginTop: 12 }}>
                    {METHODS.map((m) => (
                      <label key={m.id} className={`pay-method ${method === m.id ? "is-on" : ""}`}>
                        <input type="radio" name="_m" checked={method === m.id} onChange={() => setMethod(m.id)} />
                        <span className="pay-logo" style={{ background: m.bg, color: m.fg }}>{m.short}</span> {m.label}
                      </label>
                    ))}
                  </div>
                  {method !== "carte" && (
                    <div className="field"><label htmlFor="phone">Numéro {METHODS.find((m) => m.id === method)?.label}</label><input id="phone" name="phone" type="tel" placeholder="77 000 00 00" required /></div>
                  )}
                  <button className="btn btn-support btn-lg btn-block" style={{ marginTop: 14 }} type="submit">Envoyer {fmt(total)}</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
}

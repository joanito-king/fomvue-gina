"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { createPortal } from "react-dom";

// Le tiroir est rendu dans <body> (portail) : le header a un backdrop-filter qui piégerait un élément position:fixed.
export function MobileMenu({ links, children }: { links: { href: string; label: string }[]; children?: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  return (
    <>
      <button className="burger" type="button" aria-label="Menu" aria-expanded={open} onClick={() => setOpen(!open)}>
        <span /><span /><span />
      </button>
      {mounted && open &&
        createPortal(
          <div className="drawer is-open" onClick={(e) => (e.target as HTMLElement).closest("a") && setOpen(false)}>
            {links.map((l) => <Link key={l.href + l.label} href={l.href}>{l.label}</Link>)}
            {children}
          </div>,
          document.body,
        )}
    </>
  );
}

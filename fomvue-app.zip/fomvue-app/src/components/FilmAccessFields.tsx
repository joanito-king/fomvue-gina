"use client";
import { useState } from "react";

export function FilmAccessFields() {
  const [access, setAccess] = useState("FREE");
  const [buy, setBuy] = useState("2500");
  const net = Math.round((parseInt(buy, 10) || 0) * 0.9);
  return (
    <>
      <div className="field full">
        <label>Accès</label>
        <div className="access-picks">
          <label className={`pay-method ${access === "FREE" ? "is-on" : ""}`}><input type="radio" name="access" value="FREE" checked={access === "FREE"} onChange={() => setAccess("FREE")} /> Gratuit — pour se faire découvrir</label>
          <label className={`pay-method ${access === "PAID" ? "is-on" : ""}`}><input type="radio" name="access" value="PAID" checked={access === "PAID"} onChange={() => setAccess("PAID")} /> Payant — achat et/ou location 48 h</label>
        </div>
      </div>
      {access === "PAID" && (
        <>
          <div className="field"><label htmlFor="buyPrice">Prix d’achat (F CFA)</label><input id="buyPrice" name="buyPrice" type="number" min={0} step={50} value={buy} onChange={(e) => setBuy(e.target.value)} /></div>
          <div className="field"><label htmlFor="rentPrice">Prix de location 48 h (F CFA, facultatif)</label><input id="rentPrice" name="rentPrice" type="number" min={0} step={50} defaultValue={1000} /></div>
          <p className="tiny full">Sur un achat à {(parseInt(buy, 10) || 0).toLocaleString("fr-FR")} F CFA, vous touchez {net.toLocaleString("fr-FR")} F CFA (commission Fomvue 10 %).</p>
        </>
      )}
    </>
  );
}

import type { Product } from "@prisma/client";
import { CATEGORIES, KINDS } from "@/lib/constants";
import { saveProductAction } from "@/app/actions/vendor";

export function ProductForm({ p }: { p?: Product }) {
  return (
    <form className="panel" action={saveProductAction}>
      {p && <input type="hidden" name="id" value={p.id} />}
      <div className="form-grid">
        <div className="field full"><label htmlFor="title">Titre</label><input id="title" name="title" required minLength={3} defaultValue={p?.title} placeholder="Ex. Pack 50 prompts vidéo IA" /></div>
        <div className="field"><label htmlFor="category">Catégorie</label>
          <select id="category" name="category" defaultValue={p?.category ?? "PROMPTS"}>{CATEGORIES.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
        </div>
        <div className="field"><label htmlFor="kind">Type de produit</label>
          <select id="kind" name="kind" defaultValue={p?.kind ?? "PROMPTS"}>{Object.entries(KINDS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select>
        </div>
        <div className="field"><label htmlFor="price">Prix (F CFA)</label><input id="price" name="price" type="number" min={100} step={50} required defaultValue={p?.price ?? 5000} /></div>
        <div className="field"><label htmlFor="level">Niveau</label>
          <select id="level" name="level" defaultValue={p?.level ?? "DEBUTANT"}><option value="DEBUTANT">Débutant</option><option value="CONFIRME">Confirmé</option></select>
        </div>
        <div className="field full"><label htmlFor="description">Description</label><textarea id="description" name="description" required minLength={10} defaultValue={p?.description} placeholder="À qui s’adresse le produit, ce qu’il permet de faire…" /></div>
        <div className="field full"><label htmlFor="includes">Ce qui est inclus (une ligne par élément)</label><textarea id="includes" name="includes" defaultValue={p?.includes} placeholder={"50 prompts testés\nGuide PDF\nMises à jour gratuites"} /></div>
        <div className="field"><label htmlFor="cover">Image de couverture (facultatif)</label><input id="cover" name="cover" type="file" accept="image/*" /></div>
        <div className="field"><label htmlFor="file">Fichier livré à l’acheteur (PDF, ZIP…)</label><input id="file" name="file" type="file" />{p?.fileName && <p className="tiny">Actuel : {p.fileName}</p>}</div>
        <div className="field"><label htmlFor="status">Statut</label>
          <select id="status" name="status" defaultValue={p?.status === "DRAFT" ? "DRAFT" : "PUBLISHED"}><option value="PUBLISHED">Publié</option><option value="DRAFT">Brouillon</option></select>
        </div>
      </div>
      <button className="btn btn-primary btn-lg" style={{ marginTop: 18 }} type="submit">{p ? "Enregistrer" : "Publier le produit"}</button>
    </form>
  );
}

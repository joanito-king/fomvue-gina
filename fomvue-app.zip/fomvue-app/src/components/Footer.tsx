import Link from "next/link";
import { BRAND, SLOGAN, SLOGAN_EN } from "@/lib/constants";
import { LogoMark } from "./Logo";

export function Footer() {
  return (
    <footer>
      <div className="wrap">
        <div className="footer-grid">
          <div>
            <div className="logo" style={{ marginBottom: 12 }}>
              <LogoMark />
              <span className="logo-text">
                <span className="logo-word">{BRAND}</span>
                <span className="logo-slogan" style={{ color: "#d6b25e" }}>{SLOGAN}</span>
              </span>
            </div>
            <p className="tiny" style={{ color: "var(--footer-muted)", marginBottom: 8 }}>{SLOGAN_EN}</p>
            <p className="muted" style={{ color: "var(--footer-muted)", maxWidth: "34ch" }}>
              Ouvrez une boutique à votre nom, vendez vos créations IA et encaissez en F CFA — ou explorez le marché pour acheter.
            </p>
          </div>
          <div>
            <h4>Explorer</h4>
            <Link href="/regarder">Regarder</Link>
            <Link href="/catalogue">Catalogue</Link>
            <Link href="/catalogue?cat=scenarios">Scénarios &amp; séries</Link>
            <Link href="/catalogue?cat=formations">Formations</Link>
            <Link href="/catalogue?cat=services">Services</Link>
          </div>
          <div>
            <h4>Créateurs</h4>
            <Link href="/devenir-createur">Devenir créateur</Link>
            <Link href="/vendeur">Espace vendeur</Link>
            <Link href="/mes-achats">Bibliothèque acheteur</Link>
            <Link href="/devenir-createur">Wave, Orange Money, MTN, Moov, carte</Link>
          </div>
          <div>
            <h4>{BRAND}</h4>
            <Link href="/connexion">Connexion</Link>
            <Link href="/inscription">Créer un compte</Link>
            <span style={{ display: "block", color: "var(--footer-muted)", fontSize: ".85rem", marginTop: 6 }}>Commission : 10 % ventes · 5 % soutiens</span>
          </div>
        </div>
        <div className="legal">
          <span>© 2026 {BRAND} · {SLOGAN} · fomvue.com · Dakar, Sénégal</span>
          <span>Prix en F CFA · Conçu pour l’Afrique francophone.</span>
        </div>
      </div>
    </footer>
  );
}

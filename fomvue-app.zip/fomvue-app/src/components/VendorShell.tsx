import Link from "next/link";
import type { Shop } from "@prisma/client";
import { shopHost } from "@/lib/format";
import { Flash } from "./Cards";

const TABS = [
  { href: "/vendeur", label: "Aperçu", id: "apercu" },
  { href: "/vendeur/produits", label: "Produits", id: "produits" },
  { href: "/vendeur/films", label: "Mes films", id: "films" },
  { href: "/vendeur/soutiens", label: "Soutiens reçus", id: "soutiens" },
  { href: "/vendeur/boutique", label: "Ma boutique", id: "boutique" },
];

export function VendorShell({ shop, active, sp, children }: { shop: Shop; active: string; sp?: Record<string, string | undefined>; children: React.ReactNode }) {
  return (
    <div className="wrap" style={{ paddingBottom: 60 }}>
      <div className="page-hero">
        <div className="crumbs"><Link href="/">Accueil</Link> · Espace vendeur</div>
        <h1>Espace vendeur</h1>
        <p className="muted">
          {shop.name} · <Link className="shop-url" href={`/boutique/${shop.slug}`}>{shopHost(shop.slug)}</Link>
        </p>
        <div className="dash-tabs" style={{ marginTop: 16 }}>
          {TABS.map((t) => (
            <Link key={t.id} className={`btn ${active === t.id ? "btn-primary" : "btn-outline"}`} href={t.href}>{t.label}</Link>
          ))}
        </div>
      </div>
      <Flash error={sp?.error} ok={sp?.ok} />
      {children}
    </div>
  );
}

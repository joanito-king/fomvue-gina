import Link from "next/link";
import { currentUser } from "@/lib/auth";
import { CATEGORIES } from "@/lib/constants";
import { avatarBg, initials } from "@/lib/format";
import { logoutAction } from "@/app/actions/auth";
import { Logo } from "./Logo";
import { MobileMenu } from "./MobileMenu";

export async function Header() {
  const user = await currentUser();
  const links = [
    { href: "/", label: "Accueil" },
    { href: "/regarder", label: "Regarder" },
    { href: "/catalogue", label: "Acheter & vendre" },
    ...CATEGORIES.map((c) => ({ href: `/catalogue?cat=${c.slug}`, label: c.name })),
    { href: "/mes-achats", label: "Mes achats" },
    user?.shop ? { href: "/vendeur", label: "Espace vendeur" } : { href: "/devenir-createur", label: "Créer ma boutique" },
    ...(user?.role === "ADMIN" ? [{ href: "/admin", label: "Administration" }] : []),
    ...(user ? [] : [{ href: "/connexion", label: "Connexion" }]),
  ];
  return (
    <header className="header">
      <div className="wrap header-inner">
        <Logo />
        <nav className="nav" aria-label="Principale">
          <Link className="nav-link" href="/">Accueil</Link>
          <Link className="nav-link" href="/regarder">Regarder</Link>
          <div className="nav-drop">
            <Link className="nav-link" href="/catalogue">Acheter &amp; vendre</Link>
            <div className="nav-drop-menu">
              <Link href="/catalogue">Catalogue du marché</Link>
              {CATEGORIES.map((c) => (
                <Link key={c.id} href={`/catalogue?cat=${c.slug}`}>{c.name}</Link>
              ))}
            </div>
          </div>
          <Link className="nav-link" href="/devenir-createur">Devenir créateur</Link>
        </nav>
        <div className="header-actions">
          {user ? (
            <>
              <Link className="btn btn-ghost hide-sm" href="/mes-achats">Mes achats</Link>
              {user.role === "ADMIN" && <Link className="btn btn-ghost hide-sm" href="/admin">Admin</Link>}
              {user.shop ? (
                <Link className="btn btn-outline" href="/vendeur">Espace vendeur</Link>
              ) : (
                <Link className="btn btn-primary" href="/devenir-createur">Créer ma boutique</Link>
              )}
              <span className="user-chip hide-sm" title={user.email}>
                <span className="avatar-sm" style={{ background: avatarBg(user.email) }}>{initials(user.name)}</span>
              </span>
              <form action={logoutAction} className="inline-form hide-sm">
                <button className="btn btn-ghost btn-sm" type="submit">Déconnexion</button>
              </form>
            </>
          ) : (
            <>
              <Link className="btn btn-ghost hide-sm" href="/connexion">Connexion</Link>
              <Link className="btn btn-ghost hide-sm" href="/mes-achats">Mes achats</Link>
              <Link className="btn btn-outline" href="/vendeur">Espace vendeur</Link>
              <Link className="btn btn-primary" href="/inscription?createur=1">Créer ma boutique</Link>
            </>
          )}
          <MobileMenu links={links}>
            {user && (
              <form action={logoutAction}>
                <button type="submit">Déconnexion</button>
              </form>
            )}
          </MobileMenu>
        </div>
      </div>
    </header>
  );
}

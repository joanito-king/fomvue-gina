import { youtubeId } from "@/lib/format";

export function VideoPlayer({ url, title }: { url: string; title: string }) {
  const yt = youtubeId(url);
  return (
    <div className="video-frame">
      {yt ? (
        <iframe
          src={`https://www.youtube-nocookie.com/embed/${yt}?rel=0`}
          title={title}
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        />
      ) : (
        <video src={url} controls playsInline preload="metadata" />
      )}
    </div>
  );
}

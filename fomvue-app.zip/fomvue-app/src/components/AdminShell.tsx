import Link from "next/link";
import { Flash } from "./Cards";

export function AdminShell({ active, sp, children }: { active: string; sp?: Record<string, string | undefined>; children: React.ReactNode }) {
  const tabs = [
    { href: "/admin", id: "apercu", label: "Revenus & retraits" },
    { href: "/admin/produits", id: "produits", label: "Modération produits" },
    { href: "/admin/utilisateurs", id: "users", label: "Utilisateurs" },
  ];
  return (
    <div className="wrap" style={{ paddingBottom: 60 }}>
      <div className="page-hero">
        <div className="crumbs"><Link href="/">Accueil</Link> · Administration</div>
        <h1>Administration Fomvue</h1>
        <div className="dash-tabs" style={{ marginTop: 16 }}>
          {tabs.map((t) => <Link key={t.id} className={`btn ${active === t.id ? "btn-primary" : "btn-outline"}`} href={t.href}>{t.label}</Link>)}
        </div>
      </div>
      <Flash error={sp?.error} ok={sp?.ok} />
      {children}
    </div>
  );
}

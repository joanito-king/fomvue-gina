import Link from "next/link";
import type { Film, Product, Shop } from "@prisma/client";
import { FILM_KINDS, KINDS, LEVELS } from "@/lib/constants";
import { avatarBg, fcfa, initials, shopHost, stars } from "@/lib/format";
import { publicUrl } from "@/lib/storage";

export function LevelBadge({ level }: { level: string }) {
  return <span className={`badge-level ${level === "DEBUTANT" ? "badge-debutant" : "badge-confirme"}`}>{LEVELS[level] ?? level}</span>;
}

export function ShopAvatar({ shop, size = 40 }: { shop: Pick<Shop, "name" | "slug" | "logoKey">; size?: number }) {
  const url = publicUrl(shop.logoKey);
  return (
    <div
      className="avatar"
      style={{ position: "static", width: size, height: size, borderWidth: 0, fontSize: size / 3.2, background: avatarBg(shop.slug), overflow: "hidden" }}
    >
      {url ? <img src={url} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} /> : initials(shop.name.replace(/^boutique\s+/i, ""))}
    </div>
  );
}

export function avgRating(reviews: { stars: number }[]) {
  return reviews.length ? reviews.reduce((s, r) => s + r.stars, 0) / reviews.length : 0;
}

type ProductWithShop = Product & { shop: Shop; reviews?: { stars: number }[] };

export function ProductCard({ p }: { p: ProductWithShop }) {
  const cover = publicUrl(p.coverKey);
  const rating = avgRating(p.reviews ?? []);
  return (
    <Link className="product-card" href={`/produit/${p.id}`}>
      <div className="cover" style={{ background: p.coverColor, position: "relative" }}>
        {cover && <img className="cover-img" src={cover} alt="" />}
        <span className="tag" style={{ zIndex: 1 }}>{KINDS[p.kind]}</span>
        <strong style={{ position: "relative" }}>{p.title}</strong>
      </div>
      <div className="product-body">
        <div className="tiny">{p.shop.flag} {p.shop.name} · {KINDS[p.kind]}</div>
        <h3>{p.title}</h3>
        <div><LevelBadge level={p.level} /></div>
        <div className="price-row">
          <span className="price">{fcfa(p.price)}</span>
          {rating > 0 && <span className="stars" title={rating.toFixed(1)}>{stars(rating)}</span>}
        </div>
      </div>
    </Link>
  );
}

export function CreatorCard({ shop, sales, products }: { shop: Shop; sales: number; products: number }) {
  const logo = publicUrl(shop.logoKey);
  return (
    <Link className="creator-card" href={`/boutique/${shop.slug}`}>
      <div className="creator-cover" style={{ background: `linear-gradient(120deg, ${shop.color}, var(--footer-bg))` }} />
      <div className="avatar" style={{ background: avatarBg(shop.slug), overflow: "hidden" }}>
        {logo ? <img src={logo} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} /> : initials(shop.name.replace(/^boutique\s+/i, ""))}
      </div>
      <div className="creator-body">
        <h3>{shop.name}</h3>
        <div className="tiny">{shop.flag} {shop.city} · {shopHost(shop.slug)}</div>
        <div><LevelBadge level={shop.level} /></div>
        <p className="tiny" style={{ minHeight: "2.6em" }}>{shop.tagline}</p>
        <div className="tiny">{products} offres · {sales.toLocaleString("fr-FR")} ventes</div>
      </div>
    </Link>
  );
}

export function AccessBadges({ f }: { f: Pick<Film, "access" | "buyPrice" | "rentPrice"> }) {
  if (f.access === "FREE") return <span className="badge-free">Gratuit</span>;
  return (
    <div className="badge-paid">
      {f.buyPrice ? <span>Acheter {fcfa(f.buyPrice)}</span> : null}
      {f.rentPrice ? <span>Louer 48h {fcfa(f.rentPrice)}</span> : null}
    </div>
  );
}

export function TitleCard({ f }: { f: Film & { shop: Shop } }) {
  const poster = publicUrl(f.posterKey);
  return (
    <Link className="title-card" href={`/regarder/${f.id}`}>
      <div className="title-poster" style={{ background: f.poster, position: "relative" }}>
        {poster && <img className="cover-img" src={poster} alt="" />}
        <div style={{ position: "relative", display: "flex" }}><AccessBadges f={f} /></div>
        <strong style={{ position: "relative" }}>{f.title}</strong>
      </div>
      <div className="title-meta">
        <div className="tiny">{FILM_KINDS[f.kind]} · {f.year}</div>
        <div className="tiny">{f.shop.flag} {f.shop.name}</div>
      </div>
    </Link>
  );
}

export function Flash({ error, ok }: { error?: string | string[]; ok?: string | string[] }) {
  return (
    <>
      {error && <div className="alert alert-error" role="alert">{String(error)}</div>}
      {ok && <div className="alert alert-ok" role="status">{String(ok)}</div>}
    </>
  );
}

export function PayLogo({ m }: { m: { short: string; bg: string; fg: string } }) {
  return <span className="pay-logo" style={{ background: m.bg, color: m.fg }}>{m.short}</span>;
}

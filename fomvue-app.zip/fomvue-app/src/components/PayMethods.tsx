"use client";
import { useState } from "react";

const METHODS = [
  { id: "wave", label: "Wave", short: "WAVE", bg: "#1dc8f6", fg: "#083344" },
  { id: "orange", label: "Orange Money", short: "OM", bg: "#ff6600", fg: "#fff" },
  { id: "mtn", label: "MTN MoMo", short: "MTN", bg: "#ffcc00", fg: "#1a1a1a" },
  { id: "moov", label: "Moov Money", short: "MOOV", bg: "#0066b3", fg: "#fff" },
  { id: "carte", label: "Carte bancaire", short: "CARTE", bg: "#16141f", fg: "#fff" },
];

export function PayMethods() {
  const [method, setMethod] = useState("wave");
  const m = METHODS.find((x) => x.id === method)!;
  return (
    <>
      {METHODS.map((x) => (
        <label key={x.id} className={`pay-method ${method === x.id ? "is-on" : ""}`}>
          <input type="radio" name="method" value={x.id} checked={method === x.id} onChange={() => setMethod(x.id)} />
          <span className="pay-logo" style={{ background: x.bg, color: x.fg }}>{x.short}</span> {x.label}
        </label>
      ))}
      {method === "carte" ? (
        <p className="tiny" style={{ margin: "4px 0 8px" }}>Vous saisirez votre carte sur la page sécurisée du prestataire de paiement. Aucune donnée de carte ne transite par Fomvue.</p>
      ) : (
        <div className="field">
          <label htmlFor="phone">Numéro {m.label}</label>
          <input id="phone" name="phone" type="tel" required placeholder="77 000 00 00" autoComplete="tel" />
          <p className="tiny" style={{ marginTop: 6 }}>Une demande de validation arrivera sur ce téléphone.</p>
        </div>
      )}
    </>
  );
}

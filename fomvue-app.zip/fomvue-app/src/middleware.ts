import { NextResponse, type NextRequest } from "next/server";

/**
 * Sous-domaines de boutiques : awa-diop.fomvue.com -> /boutique/awa-diop
 * Actif seulement si ROOT_DOMAIN est défini (ex. "fomvue.com") et le DNS wildcard configuré.
 */
export function middleware(req: NextRequest) {
  const root = process.env.ROOT_DOMAIN;
  if (!root) return NextResponse.next();
  const host = (req.headers.get("host") || "").split(":")[0]!.toLowerCase();
  if (host === root || host === `www.${root}` || !host.endsWith(`.${root}`)) return NextResponse.next();
  const sub = host.slice(0, -(root.length + 1));
  if (!/^[a-z0-9-]+$/.test(sub)) return NextResponse.next();
  const url = req.nextUrl.clone();
  if (url.pathname === "/") {
    url.pathname = `/boutique/${sub}`;
    return NextResponse.rewrite(url);
  }
  return NextResponse.next();
}

export const config = { matcher: ["/"] };

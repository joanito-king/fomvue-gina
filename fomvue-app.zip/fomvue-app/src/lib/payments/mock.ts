import crypto from "node:crypto";
import type { PaymentProvider } from "./types";

/**
 * Prestataire de TEST : simule Wave / Orange Money / MTN / Moov / carte.
 * L'acheteur est envoyé sur /paiement/test/[id] (écran de validation simulé), qui émet
 * ensuite un webhook signé HMAC-SHA256 — exactement comme le ferait un vrai agrégateur.
 */
/** En production, le mode test doit être autorisé explicitement (sinon n'importe qui pourrait "payer" gratuitement). */
export const mockAllowed = () => process.env.NODE_ENV !== "production" || process.env.ALLOW_MOCK_PAYMENTS === "1";
export const mockSecret = () => process.env.MOCK_WEBHOOK_SECRET || "mock-secret";
export const signMock = (body: string) => crypto.createHmac("sha256", mockSecret()).update(body).digest("hex");

export const mockProvider: PaymentProvider = {
  name: "mock",
  async createCheckout(payment) {
    if (!mockAllowed()) throw new Error("Paiements de test désactivés en production (ALLOW_MOCK_PAYMENTS).");
    return { redirectUrl: `/paiement/test/${payment.id}`, providerRef: `MOCK-${payment.reference}` };
  },
  async parseWebhook({ body, headers }) {
    const sig = headers.get("x-mock-signature") || "";
    const expected = signMock(body);
    if (sig.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
    const data = JSON.parse(body) as { reference: string; status: string; providerRef?: string };
    return {
      reference: data.reference,
      status: data.status === "SUCCEEDED" ? "SUCCEEDED" : "FAILED",
      providerRef: data.providerRef,
      raw: body,
    };
  },
};

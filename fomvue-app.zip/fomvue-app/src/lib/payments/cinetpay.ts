import type { PaymentProvider } from "./types";

/**
 * CinetPay (UEMOA + Cameroun, RDC, Guinée) — Orange, MTN, Moov, Wave, carte.
 * Docs : https://docs.cinetpay.com/api/1.0-fr/checkout/initialisation
 * À ACTIVER : CINETPAY_API_KEY, CINETPAY_SITE_ID (+ CINETPAY_SECRET_KEY) puis PAYMENT_PROVIDER=cinetpay.
 */
const creds = () => {
  const apikey = process.env.CINETPAY_API_KEY;
  const site_id = process.env.CINETPAY_SITE_ID;
  if (!apikey || !site_id) throw new Error("CinetPay : clés manquantes (voir .env.example)");
  return { apikey, site_id };
};

export const cinetpayProvider: PaymentProvider = {
  name: "cinetpay",
  async createCheckout(payment, ctx) {
    const res = await fetch("https://api-checkout.cinetpay.com/v2/payment", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...creds(),
        transaction_id: payment.reference,
        amount: payment.amount, // XOF : multiple de 5
        currency: "XOF",
        description: ctx.description.replace(/[^\w\s-]/g, " ").slice(0, 100),
        notify_url: ctx.notifyUrl,
        return_url: ctx.returnUrl,
        channels: "ALL",
        lang: "fr",
        customer_name: ctx.customer?.name || undefined,
        customer_email: ctx.customer?.email || undefined,
      }),
    });
    const json = (await res.json()) as { code?: string; message?: string; data?: { payment_url?: string; payment_token?: string } };
    if (json.code !== "201" || !json.data?.payment_url) throw new Error(`CinetPay : ${json.message || res.status}`);
    return { redirectUrl: json.data.payment_url, providerRef: json.data.payment_token };
  },
  async parseWebhook({ body }) {
    // Notification : cpm_trans_id ; on revérifie TOUJOURS le statut via /v2/payment/check
    const form = new URLSearchParams(body);
    const reference = form.get("cpm_trans_id");
    if (!reference) return null;
    const r = await fetch("https://api-checkout.cinetpay.com/v2/payment/check", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...creds(), transaction_id: reference }),
    });
    const j = (await r.json()) as { data?: { status?: string; operator_id?: string } };
    return { reference, status: j.data?.status === "ACCEPTED" ? "SUCCEEDED" : "FAILED", providerRef: j.data?.operator_id, raw: body };
  },
};

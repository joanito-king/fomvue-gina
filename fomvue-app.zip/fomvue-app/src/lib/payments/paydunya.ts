import crypto from "node:crypto";
import type { PaymentProvider } from "./types";

/**
 * PayDunya (Sénégal, Côte d'Ivoire, Bénin, Togo, Mali, Burkina) — Wave, Orange Money, Free Money, carte...
 * Docs : https://developers.paydunya.com/doc/FR/http_json
 * À ACTIVER : renseigner PAYDUNYA_MASTER_KEY, PAYDUNYA_PRIVATE_KEY, PAYDUNYA_TOKEN, PAYDUNYA_MODE
 * puis PAYMENT_PROVIDER=paydunya. À tester en mode "test" avant le "live".
 */
const base = () =>
  process.env.PAYDUNYA_MODE === "live" ? "https://app.paydunya.com/api/v1" : "https://app.paydunya.com/sandbox-api/v1";

const headers = () => {
  const master = process.env.PAYDUNYA_MASTER_KEY;
  const priv = process.env.PAYDUNYA_PRIVATE_KEY;
  const token = process.env.PAYDUNYA_TOKEN;
  if (!master || !priv || !token) throw new Error("PayDunya : clés manquantes (voir .env.example)");
  return {
    "Content-Type": "application/json",
    "PAYDUNYA-MASTER-KEY": master,
    "PAYDUNYA-PRIVATE-KEY": priv,
    "PAYDUNYA-TOKEN": token,
  };
};

export const paydunyaProvider: PaymentProvider = {
  name: "paydunya",
  async createCheckout(payment, ctx) {
    const res = await fetch(`${base()}/checkout-invoice/create`, {
      method: "POST",
      headers: headers(),
      body: JSON.stringify({
        invoice: { total_amount: payment.amount, description: ctx.description },
        store: { name: "Fomvue", website_url: process.env.APP_URL },
        actions: { return_url: ctx.returnUrl, cancel_url: ctx.cancelUrl, callback_url: ctx.notifyUrl },
        custom_data: { reference: payment.reference },
      }),
    });
    const json = (await res.json()) as { response_code?: string; response_text?: string; token?: string };
    if (json.response_code !== "00" || !json.response_text) throw new Error(`PayDunya : ${json.response_text || res.status}`);
    return { redirectUrl: json.response_text, providerRef: json.token };
  },
  async parseWebhook({ body }) {
    // IPN envoyé en application/x-www-form-urlencoded : data[hash], data[status], data[invoice][token], data[custom_data][reference]
    const form = new URLSearchParams(body);
    const hash = form.get("data[hash]") || "";
    const expected = crypto.createHash("sha512").update(process.env.PAYDUNYA_MASTER_KEY || "").digest("hex");
    if (!hash || hash !== expected) return null;
    const token = form.get("data[invoice][token]") || undefined;
    const reference = form.get("data[custom_data][reference]") || "";
    // Double vérification auprès de PayDunya
    let status = form.get("data[status]");
    if (token) {
      const r = await fetch(`${base()}/checkout-invoice/confirm/${token}`, { headers: headers() });
      const j = (await r.json()) as { status?: string };
      status = j.status || status;
    }
    return { reference, status: status === "completed" ? "SUCCEEDED" : "FAILED", providerRef: token, raw: body };
  },
};

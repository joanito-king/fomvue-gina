import type { Payment } from "@prisma/client";

export type CheckoutContext = {
  returnUrl: string; // page de retour après paiement
  cancelUrl: string;
  notifyUrl: string; // webhook (IPN)
  description: string;
  customer?: { name?: string | null; email?: string | null; phone?: string | null };
};

export type WebhookResult = {
  reference: string;
  status: "SUCCEEDED" | "FAILED";
  providerRef?: string;
  raw: string;
};

export interface PaymentProvider {
  readonly name: string;
  /** Crée la transaction chez le prestataire et renvoie l'URL où envoyer l'acheteur. */
  createCheckout(payment: Payment, ctx: CheckoutContext): Promise<{ redirectUrl: string; providerRef?: string }>;
  /** Vérifie et décode une notification serveur-à-serveur. Renvoie null si invalide. */
  parseWebhook(input: { body: string; headers: Headers }): Promise<WebhookResult | null>;
}

import type { PaymentProvider } from "./types";
import { mockProvider } from "./mock";
import { paydunyaProvider } from "./paydunya";
import { cinetpayProvider } from "./cinetpay";

const providers: Record<string, PaymentProvider> = {
  mock: mockProvider,
  paydunya: paydunyaProvider,
  cinetpay: cinetpayProvider,
};

export const activeProviderName = () => process.env.PAYMENT_PROVIDER || "mock";
export const getProvider = (name = activeProviderName()) => {
  const p = providers[name];
  if (!p) throw new Error(`Prestataire de paiement inconnu : ${name}`);
  return p;
};
export type { PaymentProvider } from "./types";

export const BRAND = "FOMVUE";
export const SLOGAN = "Regarder • Apprendre • Créer";
export const SLOGAN_EN = "Watch • Learn • Create";

export const ROLES = { BUYER: "BUYER", CREATOR: "CREATOR", ADMIN: "ADMIN" } as const;

export const CATEGORIES = [
  { id: "SCENARIOS", slug: "scenarios", name: "Scénarios & séries", color: "#7a2e1f", bg: "linear-gradient(160deg,#7a2e1f,#c45a2a)", iconBg: "#fde4dc", desc: "Bibles, pilotes et saisons prêtes à tourner en IA." },
  { id: "IDEES", slug: "idees", name: "Idées & concepts", color: "#8a4b00", bg: "linear-gradient(160deg,#c46b10,#f0a202)", iconBg: "#ffe9b8", desc: "Concepts d’émissions, pubs et formats originaux." },
  { id: "SERVICES", slug: "services", name: "Services sur commande", color: "#0c6b56", bg: "linear-gradient(160deg,#0c6b56,#1ea37f)", iconBg: "#d5f0e8", desc: "Présentatrices, voix, montage et personnages sur mesure." },
  { id: "FORMATIONS", slug: "formations", name: "Formations", color: "#3b2d6b", bg: "linear-gradient(160deg,#3b2d6b,#7a5ad6)", iconBg: "#ece7ff", desc: "Cours structurés, du premier clip à la série complète." },
  { id: "PROMPTS", slug: "prompts", name: "Prompts & ressources", color: "#14532d", bg: "linear-gradient(160deg,#14532d,#65a30d)", iconBg: "#e5f6c8", desc: "Prompts, décors, personnages et kits réutilisables." },
] as const;

export const KINDS: Record<string, string> = {
  SCENARIO: "Scénario",
  IDEE: "Idée / concept",
  PROMPTS: "Pack de prompts",
  TEMPLATE: "Template",
  EBOOK: "Ebook",
  SERVICE: "Service sur commande",
  COACHING: "Coaching",
  FORMATION: "Formation",
  LICENCE: "Licence",
};

export const FILM_KINDS: Record<string, string> = {
  SERIE: "Série IA",
  FILM: "Film IA",
  CONTE: "Conte africain",
  TALKSHOW: "Talk-show",
};

export const LEVELS: Record<string, string> = { DEBUTANT: "Débutant", CONFIRME: "Confirmé" };

export const PAY_METHODS = [
  { id: "wave", label: "Wave", short: "WAVE", bg: "#1dc8f6", fg: "#083344" },
  { id: "orange", label: "Orange Money", short: "OM", bg: "#ff6600", fg: "#fff" },
  { id: "mtn", label: "MTN MoMo", short: "MTN", bg: "#ffcc00", fg: "#1a1a1a" },
  { id: "moov", label: "Moov Money", short: "MOOV", bg: "#0066b3", fg: "#fff" },
  { id: "carte", label: "Carte bancaire", short: "CARTE", bg: "#16141f", fg: "#fff" },
] as const;

export const TIP_PRESETS = [500, 1000, 2000, 5000];
export const RENT_HOURS = 48;

const num = (v: string | undefined, d: number) => (v && !isNaN(Number(v)) ? Number(v) : d);
export const COMMISSION = {
  sale: num(process.env.COMMISSION_SALE_PCT, 10) / 100,
  film: num(process.env.COMMISSION_FILM_PCT, 10) / 100,
  tip: num(process.env.COMMISSION_TIP_PCT, 5) / 100,
};
export const MIN_PAYOUT = num(process.env.MIN_PAYOUT, 5000);

export const catById = (id: string) => CATEGORIES.find((c) => c.id === id) ?? CATEGORIES[0];
export const catBySlug = (slug: string) => CATEGORIES.find((c) => c.slug === slug);

export const fcfa = (n: number) =>
  `${Math.round(n).toLocaleString("fr-FR").replace(/[\u202f\u00a0]/g, "\u00a0")}\u00a0F CFA`;

export const dateFr = (d: Date | string) =>
  new Date(d).toLocaleDateString("fr-FR", { day: "2-digit", month: "short", year: "numeric", timeZone: "Africa/Dakar" });

export const dateTimeFr = (d: Date | string) =>
  new Date(d).toLocaleString("fr-FR", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit", timeZone: "Africa/Dakar" });

export const slugify = (s: string) =>
  s
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 48) || "boutique";

export const initials = (name: string) =>
  name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0]!.toUpperCase())
    .join("");

export const hueOf = (s: string) => {
  let h = 0;
  for (const c of s) h = (h * 31 + c.charCodeAt(0)) % 360;
  return h;
};
export const avatarBg = (seed: string) => {
  const h = hueOf(seed);
  return `linear-gradient(145deg, hsl(${h},55%,48%), hsl(${(h + 30) % 360},55%,28%))`;
};
export const stars = (n: number) => "★".repeat(Math.round(n)) + "☆".repeat(5 - Math.round(n));

export const shopHost = (slug: string) => `${slug}.${(process.env.ROOT_DOMAIN || "fomvue.com").replace(/^www\./, "")}`;

export function youtubeId(url: string): string | null {
  const m = url.match(/(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([\w-]{11})/);
  return m ? m[1]! : null;
}

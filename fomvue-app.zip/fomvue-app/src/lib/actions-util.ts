import { ZodError } from "zod";
import { UserError } from "@/lib/services/auth";

export function errMsg(e: unknown): string {
  if (e instanceof ZodError) return e.issues.map((i) => i.message).join(" · ");
  if (e instanceof UserError) return e.message;
  if (e instanceof Error && /Image attendue|trop volumineux|PayDunya|CinetPay|S3|Paiements de test/.test(e.message)) return e.message;
  console.error(e);
  return "Une erreur est survenue. Réessayez.";
}

export const withParam = (path: string, key: string, value: string) =>
  `${path}${path.includes("?") ? "&" : "?"}${key}=${encodeURIComponent(value)}`;

export const str = (fd: FormData, k: string) => {
  const v = fd.get(k);
  return typeof v === "string" ? v : "";
};

export const safeNext = (n: string) => (n.startsWith("/") && !n.startsWith("//") ? n : "/");

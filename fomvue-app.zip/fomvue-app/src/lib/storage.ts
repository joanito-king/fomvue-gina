import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";

/**
 * Abstraction de stockage. v1 : disque local (dossier STORAGE_LOCAL_DIR).
 * Pour la production, implémenter S3Driver (AWS S3, Cloudflare R2, Backblaze...) avec @aws-sdk/client-s3
 * et passer STORAGE_DRIVER=s3. Les clés (ex. "covers/abc.png") restent identiques.
 */
export interface StorageDriver {
  put(key: string, data: Buffer, contentType?: string): Promise<void>;
  get(key: string): Promise<Buffer | null>;
  remove(key: string): Promise<void>;
}

class LocalDriver implements StorageDriver {
  constructor(private root: string) {}
  private full(key: string) {
    const p = path.resolve(this.root, key);
    if (!p.startsWith(path.resolve(this.root) + path.sep)) throw new Error("Clé invalide");
    return p;
  }
  async put(key: string, data: Buffer) {
    const p = this.full(key);
    await fs.mkdir(path.dirname(p), { recursive: true });
    await fs.writeFile(p, data);
  }
  async get(key: string) {
    try {
      return await fs.readFile(this.full(key));
    } catch {
      return null;
    }
  }
  async remove(key: string) {
    await fs.rm(this.full(key), { force: true });
  }
}

class S3DriverStub implements StorageDriver {
  async put(): Promise<void> {
    throw new Error("Stockage S3 non configuré : installez @aws-sdk/client-s3 et complétez src/lib/storage.ts");
  }
  async get(): Promise<Buffer | null> {
    throw new Error("Stockage S3 non configuré");
  }
  async remove(): Promise<void> {}
}

let driver: StorageDriver | null = null;
export function storage(): StorageDriver {
  if (!driver) {
    driver =
      process.env.STORAGE_DRIVER === "s3"
        ? new S3DriverStub()
        : new LocalDriver(path.resolve(process.env.STORAGE_LOCAL_DIR || "./uploads"));
  }
  return driver;
}

const IMAGE_TYPES = ["image/png", "image/jpeg", "image/webp", "image/gif"];
export const MAX_IMAGE = 5 * 1024 * 1024;
export const MAX_FILE = 50 * 1024 * 1024;

/** Enregistre un fichier issu d'un formulaire. Retourne la clé, ou null si vide. */
export async function saveUpload(file: File | null | undefined, folder: "covers" | "logos" | "files" | "posters") {
  if (!file || typeof file === "string" || file.size === 0) return null;
  const isImage = folder !== "files";
  if (isImage && !IMAGE_TYPES.includes(file.type)) throw new Error("Image attendue (PNG, JPG, WEBP, GIF).");
  if (file.size > (isImage ? MAX_IMAGE : MAX_FILE)) throw new Error("Fichier trop volumineux.");
  let ext = (file.name.split(".").pop() || "bin").toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 8);
  if (isImage) ext = ({ "image/png": "png", "image/jpeg": "jpg", "image/webp": "webp", "image/gif": "gif" } as Record<string, string>)[file.type]!;
  const key = `${folder}/${crypto.randomBytes(12).toString("hex")}.${ext}`;
  await storage().put(key, Buffer.from(await file.arrayBuffer()), file.type);
  return key;
}

export const publicUrl = (key: string | null | undefined) => (key ? `/api/files/${key}` : null);

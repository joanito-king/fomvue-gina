import "server-only";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { cache } from "react";
import { userFromToken } from "@/lib/services/auth";

export const SESSION_COOKIE = "fmv_session";

export const currentUser = cache(async () => {
  const jar = await cookies();
  return userFromToken(jar.get(SESSION_COOKIE)?.value);
});

export async function setSessionCookie(token: string, expiresAt: Date) {
  const jar = await cookies();
  jar.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production" && (process.env.APP_URL || "").startsWith("https"),
    path: "/",
    expires: expiresAt,
  });
}

export async function requireUser(next = "/") {
  const u = await currentUser();
  if (!u) redirect(`/connexion?next=${encodeURIComponent(next)}`);
  return u;
}

export async function requireCreator() {
  const u = await requireUser("/vendeur");
  if (!u.shop) redirect("/devenir-createur");
  return { user: u, shop: u.shop };
}

export async function requireAdmin() {
  const u = await requireUser("/admin");
  if (u.role !== "ADMIN") redirect("/");
  return u;
}

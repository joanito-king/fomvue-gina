import bcrypt from "bcryptjs";
import crypto from "node:crypto";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { slugify } from "@/lib/format";

export const SESSION_DAYS = 30;

export const signupSchema = z.object({
  name: z.string().trim().min(2, "Nom trop court").max(80),
  email: z.string().trim().toLowerCase().email("E-mail invalide"),
  password: z.string().min(8, "8 caractères minimum").max(200),
  asCreator: z.boolean().default(false),
  shopName: z.string().trim().max(80).optional(),
});

export class UserError extends Error {}

export const hashToken = (t: string) => crypto.createHash("sha256").update(t).digest("hex");

export async function uniqueShopSlug(base: string) {
  const root = slugify(base);
  let slug = root;
  for (let i = 2; await prisma.shop.findUnique({ where: { slug } }); i++) slug = `${root}-${i}`;
  return slug;
}

export async function signup(input: z.input<typeof signupSchema>) {
  const data = signupSchema.parse(input);
  const exists = await prisma.user.findUnique({ where: { email: data.email } });
  if (exists) throw new UserError("Un compte existe déjà avec cet e-mail.");
  const passwordHash = await bcrypt.hash(data.password, 10);
  const user = await prisma.user.create({
    data: { email: data.email, name: data.name, passwordHash, role: data.asCreator ? "CREATOR" : "BUYER" },
  });
  if (data.asCreator) await createShopFor(user.id, data.shopName || `Boutique ${data.name}`);
  return user;
}

export async function createShopFor(userId: string, shopName: string) {
  const slug = await uniqueShopSlug(shopName.replace(/^boutique\s+/i, ""));
  const shop = await prisma.shop.create({ data: { ownerId: userId, name: shopName, slug, tagline: "Créations IA" } });
  await prisma.user.update({ where: { id: userId }, data: { role: "CREATOR" } }).catch(() => null);
  return shop;
}

export async function verifyCredentials(email: string, password: string) {
  const user = await prisma.user.findUnique({ where: { email: email.trim().toLowerCase() } });
  if (!user || !(await bcrypt.compare(password, user.passwordHash))) throw new UserError("E-mail ou mot de passe incorrect.");
  if (user.suspended) throw new UserError("Ce compte est suspendu. Contactez l’équipe Fomvue.");
  return user;
}

export async function createSession(userId: string) {
  const token = crypto.randomBytes(32).toString("base64url");
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 864e5);
  await prisma.session.create({ data: { userId, tokenHash: hashToken(token), expiresAt } });
  return { token, expiresAt };
}

export async function userFromToken(token: string | undefined) {
  if (!token) return null;
  const s = await prisma.session.findUnique({
    where: { tokenHash: hashToken(token) },
    include: { user: { include: { shop: true } } },
  });
  if (!s || s.expiresAt < new Date() || s.user.suspended) return null;
  return s.user;
}

export async function destroySession(token: string | undefined) {
  if (token) await prisma.session.deleteMany({ where: { tokenHash: hashToken(token) } });
}

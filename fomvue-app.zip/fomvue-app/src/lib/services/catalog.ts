import { z } from "zod";
import { prisma } from "@/lib/db";
import { CATEGORIES, KINDS, FILM_KINDS } from "@/lib/constants";
import { slugify } from "@/lib/format";
import { UserError } from "./auth";

const catIds = CATEGORIES.map((c) => c.id) as [string, ...string[]];
const kindIds = Object.keys(KINDS) as [string, ...string[]];

export const productSchema = z.object({
  title: z.string().trim().min(3, "Titre trop court").max(120),
  category: z.enum(catIds),
  kind: z.enum(kindIds),
  level: z.enum(["DEBUTANT", "CONFIRME"]).default("DEBUTANT"),
  description: z.string().trim().min(10, "Description trop courte").max(5000),
  includes: z.string().max(3000).default(""),
  price: z.coerce.number().int().min(100, "Prix minimum 100 F CFA").max(5_000_000),
  status: z.enum(["DRAFT", "PUBLISHED"]).default("PUBLISHED"),
});

export async function createProduct(shopId: string, input: z.input<typeof productSchema>, extra: { coverKey?: string | null; fileKey?: string | null; fileName?: string | null } = {}) {
  const d = productSchema.parse(input);
  let slug = slugify(d.title);
  for (let i = 2; await prisma.product.findUnique({ where: { shopId_slug: { shopId, slug } } }); i++) slug = `${slugify(d.title)}-${i}`;
  const cat = CATEGORIES.find((c) => c.id === d.category)!;
  return prisma.product.create({
    // PRODUCT_MODERATION=pre : chaque nouveau produit attend la validation de l'admin
    data: { ...d, status: process.env.PRODUCT_MODERATION === "pre" && d.status === "PUBLISHED" ? "PENDING" : d.status, shopId, slug, coverColor: cat.bg, ...stripNull(extra) },
  });
}

export async function updateProduct(shopId: string, productId: string, input: z.input<typeof productSchema>, extra: { coverKey?: string | null; fileKey?: string | null; fileName?: string | null } = {}) {
  const p = await prisma.product.findUnique({ where: { id: productId } });
  if (!p || p.shopId !== shopId) throw new UserError("Produit introuvable.");
  const d = productSchema.parse(input);
  // un produit refusé par la modération repasse en attente après modification
  const status = p.status === "REJECTED" ? "PENDING" : d.status;
  return prisma.product.update({ where: { id: p.id }, data: { ...d, status, ...stripNull(extra) } });
}

export async function deleteProduct(shopId: string, productId: string) {
  const p = await prisma.product.findUnique({ where: { id: productId }, include: { _count: { select: { orders: true } } } });
  if (!p || p.shopId !== shopId) throw new UserError("Produit introuvable.");
  // On ne supprime pas un produit déjà vendu (les acheteurs gardent l'accès) : on l'archive.
  if (p._count.orders > 0) return prisma.product.update({ where: { id: p.id }, data: { status: "DRAFT" } });
  return prisma.product.delete({ where: { id: p.id } });
}

function stripNull<T extends Record<string, unknown>>(o: T) {
  return Object.fromEntries(Object.entries(o).filter(([, v]) => v !== null && v !== undefined)) as Partial<T>;
}

export const lessonSchema = z.object({
  section: z.string().trim().min(1).max(80).default("Module 1"),
  title: z.string().trim().min(2).max(120),
  content: z.string().max(10000).default(""),
  videoUrl: z.string().trim().url().optional().or(z.literal("")).transform((v) => v || null),
  durationMin: z.coerce.number().int().min(1).max(600).default(5),
});

export async function addLesson(shopId: string, productId: string, input: z.input<typeof lessonSchema>) {
  const p = await prisma.product.findUnique({ where: { id: productId } });
  if (!p || p.shopId !== shopId) throw new UserError("Formation introuvable.");
  const d = lessonSchema.parse(input);
  const position = await prisma.lesson.count({ where: { productId } });
  return prisma.lesson.create({ data: { ...d, productId, position } });
}

export const filmSchema = z
  .object({
    title: z.string().trim().min(2).max(120),
    kind: z.enum(Object.keys(FILM_KINDS) as [string, ...string[]]),
    synopsis: z.string().trim().min(10).max(3000),
    videoUrl: z.string().trim().url("Lien vidéo invalide (MP4 ou YouTube)"),
    durationLabel: z.string().trim().max(60).default(""),
    ageRating: z.string().trim().max(20).default("Tous publics"),
    access: z.enum(["FREE", "PAID"]),
    buyPrice: z.coerce.number().int().min(0).max(1_000_000).optional(),
    rentPrice: z.coerce.number().int().min(0).max(1_000_000).optional(),
  })
  .refine((f) => f.access === "FREE" || (f.buyPrice ?? 0) >= 100 || (f.rentPrice ?? 0) >= 100, {
    message: "Un titre payant doit avoir un prix d’achat ou de location (min. 100 F CFA).",
  });

const POSTERS = [
  "linear-gradient(160deg,#161428,#2f2a7a 55%,#8a6410)",
  "linear-gradient(160deg,#0a3d34,#0a5c4d 60%,#c9a227)",
  "linear-gradient(160deg,#3b1d0b,#8a3218 60%,#e0a83d)",
  "linear-gradient(160deg,#1e1b4b,#4a45a0 60%,#d6b25e)",
];

export async function createFilm(shopId: string, input: z.input<typeof filmSchema>, posterKey?: string | null) {
  const d = filmSchema.parse(input);
  const n = await prisma.film.count({ where: { shopId } });
  return prisma.film.create({
    data: {
      ...d,
      buyPrice: d.access === "PAID" && d.buyPrice ? d.buyPrice : null,
      rentPrice: d.access === "PAID" && d.rentPrice ? d.rentPrice : null,
      shopId,
      poster: POSTERS[n % POSTERS.length]!,
      posterKey: posterKey || null,
    },
  });
}

export async function deleteFilm(shopId: string, filmId: string) {
  const f = await prisma.film.findUnique({ where: { id: filmId }, include: { _count: { select: { accesses: true } } } });
  if (!f || f.shopId !== shopId) throw new UserError("Titre introuvable.");
  if (f._count.accesses > 0) return prisma.film.update({ where: { id: f.id }, data: { status: "DRAFT" } });
  return prisma.film.delete({ where: { id: f.id } });
}

export async function hasFilmAccess(userId: string | null | undefined, film: { id: string; access: string; shopId: string }, ownerShopId?: string | null) {
  if (film.access === "FREE") return true;
  if (!userId) return false;
  if (ownerShopId && ownerShopId === film.shopId) return true;
  const a = await prisma.filmAccess.findFirst({
    where: { userId, filmId: film.id, OR: [{ mode: "BUY" }, { expiresAt: { gt: new Date() } }] },
    orderBy: { createdAt: "desc" },
  });
  return !!a;
}

export async function ownsProduct(userId: string | null | undefined, productId: string) {
  if (!userId) return false;
  const p = await prisma.product.findUnique({ where: { id: productId }, include: { shop: true } });
  if (p?.shop.ownerId === userId) return true;
  return !!(await prisma.order.findFirst({ where: { buyerId: userId, productId } }));
}

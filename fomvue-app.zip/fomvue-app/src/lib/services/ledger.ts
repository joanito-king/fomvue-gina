import { prisma } from "@/lib/db";
import { MIN_PAYOUT } from "@/lib/constants";
import { UserError } from "./auth";

export async function shopBalance(shopId: string) {
  const r = await prisma.ledgerEntry.aggregate({ where: { shopId, account: "CREATOR" }, _sum: { amount: true } });
  return r._sum.amount ?? 0;
}

export async function requestPayout(shopId: string, amount: number, method: string, phone: string) {
  if (!Number.isInteger(amount) || amount < MIN_PAYOUT) throw new UserError(`Retrait minimum : ${MIN_PAYOUT} F CFA.`);
  if (!/^[+\d\s]{8,20}$/.test(phone)) throw new UserError("Numéro de téléphone invalide.");
  return prisma.$transaction(async (tx) => {
    const r = await tx.ledgerEntry.aggregate({ where: { shopId, account: "CREATOR" }, _sum: { amount: true } });
    const balance = r._sum.amount ?? 0;
    if (amount > balance) throw new UserError("Solde insuffisant.");
    const payout = await tx.payout.create({ data: { shopId, amount, method, phone } });
    // Le montant est réservé immédiatement (débit) ; il est recrédité si l'admin refuse.
    await tx.ledgerEntry.create({
      data: { account: "CREATOR", shopId, type: "PAYOUT", amount: -amount, payoutId: payout.id, label: `Retrait ${method}` },
    });
    return payout;
  });
}

export async function processPayout(payoutId: string, decision: "PAID" | "REJECTED", note?: string) {
  return prisma.$transaction(async (tx) => {
    const p = await tx.payout.findUnique({ where: { id: payoutId } });
    if (!p || p.status !== "REQUESTED") throw new UserError("Retrait déjà traité.");
    await tx.payout.update({ where: { id: p.id }, data: { status: decision, note, processedAt: new Date() } });
    if (decision === "REJECTED")
      await tx.ledgerEntry.create({
        data: { account: "CREATOR", shopId: p.shopId, type: "PAYOUT_REVERSAL", amount: p.amount, payoutId: p.id, label: "Retrait refusé" },
      });
  });
}

export async function platformRevenue() {
  const rows = await prisma.ledgerEntry.groupBy({ by: ["type"], where: { account: "PLATFORM" }, _sum: { amount: true } });
  const by = Object.fromEntries(rows.map((r) => [r.type, r._sum.amount ?? 0])) as Record<string, number>;
  return {
    sales: by.COMMISSION_SALE ?? 0,
    films: by.COMMISSION_FILM ?? 0,
    tips: by.COMMISSION_TIP ?? 0,
    total: (by.COMMISSION_SALE ?? 0) + (by.COMMISSION_FILM ?? 0) + (by.COMMISSION_TIP ?? 0),
  };
}

import crypto from "node:crypto";
import type { Prisma } from "@prisma/client";
import { prisma } from "@/lib/db";
import { COMMISSION, RENT_HOURS } from "@/lib/constants";
import { getProvider, activeProviderName } from "@/lib/payments";
import type { WebhookResult } from "@/lib/payments/types";
import { UserError } from "./auth";

const appUrl = () => (process.env.APP_URL || "http://localhost:3000").replace(/\/$/, "");
const newRef = () => `FMV-${Date.now().toString(36).toUpperCase()}-${crypto.randomBytes(3).toString("hex").toUpperCase()}`;
export const split = (amount: number, rate: number) => {
  const commission = Math.round(amount * rate);
  return { commission, creatorNet: amount - commission };
};

type Start =
  | { purpose: "ORDER"; productId: string }
  | { purpose: "FILM"; filmId: string; mode: "BUY" | "RENT" }
  | { purpose: "TIP"; shopId: string; amount: number; message?: string; senderName?: string; filmId?: string };

export async function startCheckout(
  input: Start & { userId: string | null; method: string; phone?: string },
): Promise<{ paymentId: string; redirectUrl: string }> {
  let amount = 0;
  let description = "";
  const data: Partial<Prisma.PaymentUncheckedCreateInput> = {};

  if (input.purpose === "ORDER") {
    if (!input.userId) throw new UserError("Connectez-vous pour acheter.");
    const p = await prisma.product.findUnique({ where: { id: input.productId }, include: { shop: true } });
    if (!p || p.status !== "PUBLISHED") throw new UserError("Produit indisponible.");
    if (p.shop.ownerId === input.userId) throw new UserError("Vous ne pouvez pas acheter votre propre produit.");
    const owned = await prisma.order.findFirst({ where: { buyerId: input.userId, productId: p.id } });
    if (owned && p.kind !== "SERVICE" && p.kind !== "COACHING") throw new UserError("Vous possédez déjà ce produit (voir Mes achats).");
    amount = p.price;
    description = `${p.title} — ${p.shop.name}`;
    data.productId = p.id;
  } else if (input.purpose === "FILM") {
    if (!input.userId) throw new UserError("Connectez-vous pour acheter ou louer.");
    const f = await prisma.film.findUnique({ where: { id: input.filmId }, include: { shop: true } });
    if (!f || f.access !== "PAID") throw new UserError("Ce titre n’est pas payant.");
    const price = input.mode === "BUY" ? f.buyPrice : f.rentPrice;
    if (!price) throw new UserError("Option indisponible pour ce titre.");
    amount = price;
    description = `${input.mode === "BUY" ? "Achat" : "Location 48 h"} — ${f.title}`;
    data.filmId = f.id;
    data.filmMode = input.mode;
  } else {
    const shop = await prisma.shop.findUnique({ where: { id: input.shopId } });
    if (!shop) throw new UserError("Créateur introuvable.");
    if (!Number.isInteger(input.amount) || input.amount < 100 || input.amount > 1_000_000)
      throw new UserError("Montant entre 100 et 1 000 000 F CFA.");
    amount = input.amount;
    description = `Soutien à ${shop.name}`;
    data.shopId = shop.id;
    data.filmId = input.filmId || null;
    data.tipMessage = input.message?.slice(0, 280) || null;
    data.payerName = input.senderName?.slice(0, 60) || null;
  }

  const provider = getProvider();
  const payment = await prisma.payment.create({
    data: {
      ...data,
      reference: newRef(),
      provider: provider.name,
      method: input.method,
      purpose: input.purpose,
      amount,
      userId: input.userId,
      payerPhone: input.phone || null,
    } as Prisma.PaymentUncheckedCreateInput,
  });
  const user = input.userId ? await prisma.user.findUnique({ where: { id: input.userId } }) : null;
  const { redirectUrl, providerRef } = await provider.createCheckout(payment, {
    description,
    returnUrl: `${appUrl()}/paiement/retour/${payment.id}`,
    cancelUrl: `${appUrl()}/paiement/retour/${payment.id}?annule=1`,
    notifyUrl: `${appUrl()}/api/webhooks/${provider.name}`,
    customer: { name: user?.name ?? data.payerName, email: user?.email, phone: input.phone },
  });
  if (providerRef) await prisma.payment.update({ where: { id: payment.id }, data: { providerRef } });
  return { paymentId: payment.id, redirectUrl };
}

/** Webhook HTTP brut -> événement appliqué. */
export async function handleWebhook(providerName: string, body: string, headers: Headers) {
  const provider = getProvider(providerName);
  const evt = await provider.parseWebhook({ body, headers });
  if (!evt) return { ok: false as const, error: "signature invalide" };
  return { ok: true as const, ...(await applyPaymentEvent(evt)) };
}

/**
 * Applique un événement de paiement de façon IDEMPOTENTE :
 * crée la commande / l'accès film / le soutien et les écritures du grand livre.
 */
export async function applyPaymentEvent(evt: WebhookResult) {
  return prisma.$transaction(async (tx) => {
    const payment = await tx.payment.findUnique({ where: { reference: evt.reference } });
    if (!payment) return { applied: false, reason: "inconnu" };
    if (payment.status !== "PENDING") return { applied: false, reason: "déjà traité", status: payment.status };

    const claimed = await tx.payment.updateMany({
      where: { id: payment.id, status: "PENDING" },
      data: { status: evt.status, rawEvent: evt.raw.slice(0, 4000), providerRef: evt.providerRef ?? payment.providerRef },
    });
    if (claimed.count !== 1) return { applied: false, reason: "concurrence" };
    if (evt.status !== "SUCCEEDED") return { applied: true, status: evt.status };

    if (payment.purpose === "ORDER" && payment.productId && payment.userId) {
      const product = await tx.product.findUniqueOrThrow({ where: { id: payment.productId } });
      const { commission, creatorNet } = split(payment.amount, COMMISSION.sale);
      const count = await tx.order.count();
      await tx.order.create({
        data: {
          number: `CMD-${String(1001 + count).padStart(5, "0")}`,
          buyerId: payment.userId,
          productId: product.id,
          shopId: product.shopId,
          amount: payment.amount,
          commission,
          creatorNet,
          paymentId: payment.id,
        },
      });
      await tx.ledgerEntry.createMany({
        data: [
          { account: "CREATOR", shopId: product.shopId, type: "SALE", amount: creatorNet, paymentId: payment.id, label: product.title },
          { account: "PLATFORM", shopId: product.shopId, type: "COMMISSION_SALE", amount: commission, paymentId: payment.id, label: product.title },
        ],
      });
    } else if (payment.purpose === "FILM" && payment.filmId && payment.userId) {
      const film = await tx.film.findUniqueOrThrow({ where: { id: payment.filmId } });
      const { commission, creatorNet } = split(payment.amount, COMMISSION.film);
      const mode = payment.filmMode === "RENT" ? "RENT" : "BUY";
      await tx.filmAccess.create({
        data: {
          userId: payment.userId,
          filmId: film.id,
          mode,
          expiresAt: mode === "RENT" ? new Date(Date.now() + RENT_HOURS * 3600e3) : null,
          amount: payment.amount,
          commission,
          creatorNet,
          paymentId: payment.id,
        },
      });
      const label = `${mode === "RENT" ? "Location" : "Achat"} — ${film.title}`;
      await tx.ledgerEntry.createMany({
        data: [
          { account: "CREATOR", shopId: film.shopId, type: "FILM", amount: creatorNet, paymentId: payment.id, label },
          { account: "PLATFORM", shopId: film.shopId, type: "COMMISSION_FILM", amount: commission, paymentId: payment.id, label },
        ],
      });
    } else if (payment.purpose === "TIP" && payment.shopId) {
      const { commission, creatorNet } = split(payment.amount, COMMISSION.tip);
      const sender = payment.userId ? await tx.user.findUnique({ where: { id: payment.userId } }) : null;
      await tx.tip.create({
        data: {
          shopId: payment.shopId,
          senderId: payment.userId,
          senderName: payment.payerName || sender?.name || "Anonyme",
          message: payment.tipMessage,
          filmId: payment.filmId,
          amount: payment.amount,
          commission,
          creatorNet,
          paymentId: payment.id,
        },
      });
      await tx.ledgerEntry.createMany({
        data: [
          { account: "CREATOR", shopId: payment.shopId, type: "TIP", amount: creatorNet, paymentId: payment.id, label: "Soutien" },
          { account: "PLATFORM", shopId: payment.shopId, type: "COMMISSION_TIP", amount: commission, paymentId: payment.id, label: "Soutien" },
        ],
      });
    }
    return { applied: true, status: "SUCCEEDED" };
  });
}

export const providerLabel = () => activeProviderName();

import { storage } from "@/lib/storage";

const TYPES: Record<string, string> = { png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", webp: "image/webp", gif: "image/gif" };
const PUBLIC = ["covers", "logos", "posters"];

export async function GET(_req: Request, { params }: { params: Promise<{ key: string[] }> }) {
  const { key } = await params;
  if (!PUBLIC.includes(key[0] ?? "")) return new Response("Introuvable", { status: 404 });
  const data = await storage().get(key.join("/"));
  if (!data) return new Response("Introuvable", { status: 404 });
  const ext = key.at(-1)!.split(".").pop()!.toLowerCase();
  return new Response(new Uint8Array(data), {
    headers: { "Content-Type": TYPES[ext] ?? "application/octet-stream", "Cache-Control": "public, max-age=31536000, immutable", "X-Content-Type-Options": "nosniff" },
  });
}

import { handleWebhook } from "@/lib/services/payments";

// Point d'entrée des notifications de paiement (IPN) : /api/webhooks/mock | paydunya | cinetpay
export async function POST(req: Request, { params }: { params: Promise<{ provider: string }> }) {
  const { provider } = await params;
  const body = await req.text();
  try {
    const r = await handleWebhook(provider, body, req.headers);
    return Response.json(r, { status: r.ok ? 200 : 401 });
  } catch (e) {
    console.error("webhook", provider, e);
    return Response.json({ ok: false, error: "erreur" }, { status: 400 });
  }
}

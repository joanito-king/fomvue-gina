import Link from "next/link";
import { signupAction } from "@/app/actions/auth";
import { Flash } from "@/components/Cards";

export const metadata = { title: "Créer un compte" };
type SP = Promise<Record<string, string | undefined>>;

export default async function Page({ searchParams }: { searchParams: SP }) {
  const sp = await searchParams;
  const creator = sp.createur === "1";
  return (
    <div className="wrap">
      <div className="panel auth-card">
        <h1 style={{ fontSize: "1.8rem" }}>{creator ? "Créer ma boutique" : "Créer un compte"}</h1>
        <p className="muted">{creator ? "Gratuit, sans carte. Votre boutique est en ligne en une minute." : "Pour acheter, regarder et soutenir les créateurs IA."}</p>
        <Flash error={sp.error} />
        <form action={signupAction}>
          <input type="hidden" name="next" value={sp.next ?? ""} />
          <div className="field"><label htmlFor="name">Nom complet</label><input id="name" name="name" required minLength={2} autoComplete="name" /></div>
          <div className="field"><label htmlFor="email">E-mail</label><input id="email" name="email" type="email" required autoComplete="email" /></div>
          <div className="field"><label htmlFor="password">Mot de passe (8 caractères min.)</label><input id="password" name="password" type="password" required minLength={8} autoComplete="new-password" /></div>
          <label className="pay-method" style={{ marginTop: 14 }}>
            <input type="checkbox" name="asCreator" value="1" defaultChecked={creator} /> Je suis créateur·rice et je veux ouvrir ma boutique
          </label>
          <div className="field"><label htmlFor="shopName">Nom de la boutique (si créateur)</label><input id="shopName" name="shopName" placeholder="Ex. Studio Awa" /></div>
          <button className="btn btn-primary btn-lg btn-block" style={{ marginTop: 18 }} type="submit">Créer mon compte</button>
        </form>
        <p className="tiny" style={{ marginTop: 14, textAlign: "center" }}>
          Déjà inscrit ? <Link className="link-arrow" href="/connexion">Se connecter</Link>
        </p>
      </div>
    </div>
  );
}

import Link from "next/link";
import { prisma } from "@/lib/db";
import { BRAND, CATEGORIES, PAY_METHODS, SLOGAN, SLOGAN_EN } from "@/lib/constants";
import { fcfa } from "@/lib/format";
import { CreatorCard, ProductCard } from "@/components/Cards";
import { CatIcon } from "@/components/CatIcon";

export const dynamic = "force-dynamic";

export default async function Home() {
  const [products, shops, counts, paid] = await Promise.all([
    prisma.product.findMany({
      where: { status: "PUBLISHED" },
      orderBy: [{ featured: "desc" }, { createdAt: "desc" }],
      take: 8,
      include: { shop: true, reviews: { select: { stars: true } } },
    }),
    prisma.shop.findMany({ include: { _count: { select: { orders: true, products: true } } } }),
    Promise.all([prisma.shop.count(), prisma.product.count({ where: { status: "PUBLISHED" } }), prisma.film.count({ where: { status: "PUBLISHED" } })]),
    prisma.ledgerEntry.aggregate({ where: { account: "CREATOR", amount: { gt: 0 } }, _sum: { amount: true } }),
  ]);
  const top = [...shops].sort((a, b) => b._count.orders - a._count.orders).slice(0, 4);
  const hero = products.slice(0, 3);
  return (
    <>
      <section className="hero">
        <div className="wrap hero-grid">
          <div>
            <div className="eyebrow"><span className="eyebrow-dot" /> {SLOGAN} <span className="slogan-en">· {SLOGAN_EN}</span></div>
            <h1>Votre boutique.<br /><em>Vos créations IA.</em><br />Vos paiements en F&nbsp;CFA.</h1>
            <p className="lead">
              Ouvrez une vitrine à votre nom, vendez scénarios, ebooks, templates, formations, coachings et licences, et encaissez par Wave,
              Orange Money, MTN, Moov ou carte. Les acheteurs vous trouvent aussi dans le marché.
            </p>
            <div className="cta-row">
              <Link className="btn btn-primary btn-lg" href="/devenir-createur">Créer ma boutique gratuitement</Link>
              <Link className="btn btn-outline btn-lg" href="/catalogue">Explorer le marché</Link>
            </div>
            <form className="search-bar" action="/catalogue">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#8a8494" strokeWidth="2"><circle cx="11" cy="11" r="7" /><path d="M20 20l-3-3" /></svg>
              <input type="search" name="q" placeholder="Création ou boutique…" aria-label="Rechercher" />
              <button className="btn btn-primary" type="submit">Rechercher</button>
            </form>
            <div className="pay-row" style={{ marginTop: 16 }}>
              {PAY_METHODS.map((m) => (
                <span className="pay-chip" key={m.id}>
                  <span className="pay-logo" style={{ width: 30, height: 18, fontSize: ".5rem", background: m.bg, color: m.fg }}>{m.short}</span> {m.label.replace(" MoMo", "").replace(" Money", "").replace(" bancaire", "").replace("Orange", "Orange Money")}
                </span>
              ))}
            </div>
          </div>
          <div className="hero-collage" aria-hidden="true">
            {hero.map((p, i) => (
              <div key={p.id} className={`poster p${i + 1}`} style={{ background: p.coverColor }}>
                <span className="badge-cat">{CATEGORIES.find((c) => c.id === p.category)?.name}</span>
                <strong>{p.title}</strong>
                <small>{p.shop.name} · {fcfa(p.price)}</small>
              </div>
            ))}
          </div>
        </div>
      </section>
      <div className="wrap">
        <div className="stat-band">
          <div><div className="v">{fcfa(paid._sum.amount ?? 0).replace("F CFA", "F")}</div><div className="k">reversés aux créateurs</div></div>
          <div><div className="v">{counts[0]}</div><div className="k">boutiques ouvertes</div></div>
          <div><div className="v">{counts[1] + counts[2]}</div><div className="k">créations et titres en ligne</div></div>
          <div><div className="v">10&nbsp;%</div><div className="k">de commission, 0&nbsp;abonnement</div></div>
        </div>
      </div>
      <section>
        <div className="wrap">
          <div className="section-head">
            <div>
              <h2>Un marché pour être trouvé</h2>
              <p className="muted">Chaque créateur a sa boutique. En plus, le catalogue fait découvrir scénarios, idées, prompts, services et formations.</p>
            </div>
            <Link className="link-arrow" href="/catalogue">Tout le catalogue →</Link>
          </div>
          <div className="cat-grid">
            {CATEGORIES.map((c) => (
              <Link key={c.id} className="cat-card" href={`/catalogue?cat=${c.slug}`}>
                <div className="cat-icon" style={{ background: c.iconBg, color: c.color }}><CatIcon slug={c.slug} /></div>
                <h3>{c.name}</h3>
                <p>{c.desc}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>
      <section>
        <div className="wrap">
          <div className="section-head">
            <div>
              <h2>Créateurs à la une</h2>
              <p className="muted">Chaque profil est une boutique, avec son adresse et ses couleurs.</p>
            </div>
          </div>
          <div className="creator-grid">
            {top.map((s) => (
              <CreatorCard key={s.id} shop={s} sales={s._count.orders} products={s._count.products} />
            ))}
          </div>
        </div>
      </section>
      <section>
        <div className="wrap">
          <div className="watch-teaser">
            <div>
              <div className="watch-kicker">Espace Regarder</div>
              <h2>Films, séries et talk-shows IA</h2>
              <p>Certains titres sont gratuits, pour découvrir un créateur. D’autres s’achètent ou se louent 48 h en F CFA. {BRAND} ne prend de commission que sur le payant.</p>
            </div>
            <div style={{ textAlign: "right" }}>
              <Link className="btn btn-primary btn-lg" href="/regarder" style={{ background: "#fff", color: "var(--primary)" }}>Ouvrir Regarder</Link>
            </div>
          </div>
          <div className="section-head">
            <div>
              <h2>Créations du moment</h2>
              <p className="muted">Ebooks, templates, services, formations et licences, en F CFA.</p>
            </div>
            <Link className="link-arrow" href="/catalogue">Voir tout →</Link>
          </div>
          <div className="product-grid">
            {products.map((p) => <ProductCard key={p.id} p={p} />)}
          </div>
        </div>
      </section>
      <section>
        <div className="wrap">
          <div className="section-head">
            <div>
              <h2>Tout ce qu’il faut pour vendre, au même endroit</h2>
              <p className="muted">Pensé pour les créateurs IA, débutants comme confirmés.</p>
            </div>
          </div>
          <div className="benefit-grid">
            <div className="benefit"><h3>Boutique à votre nom</h3><p className="muted">Logo, couleurs, texte d’accueil et adresse du type nom.fomvue.com — sans savoir coder.</p></div>
            <div className="benefit"><h3>Paiements locaux</h3><p className="muted">Wave, Orange Money, MTN, Moov et carte. Vous recevez en F CFA.</p></div>
            <div className="benefit"><h3>Regarder</h3><p className="muted">Publiez films et séries IA en gratuit pour vous faire connaître, ou en payant (achat ou location 48 h).</p></div>
            <div className="benefit"><h3>Soutien des fans</h3><p className="muted">Un bouton « Soutenir le créateur » sur vos titres et votre boutique : 500, 1 000, 2 000 F CFA ou montant libre.</p></div>
            <div className="benefit"><h3>Bibliothèque acheteur</h3><p className="muted">Ebooks, templates, licences et formations restent accessibles au même endroit, pour toujours.</p></div>
            <div className="benefit"><h3>Stats et retraits</h3><p className="muted">Ventes, revenus, retraits Wave ou Orange Money dès 5&nbsp;000 F CFA.</p></div>
            <div className="benefit"><h3>Formations</h3><p className="muted">Programme en modules, lecteur de cours et progression de l’élève.</p></div>
            <div className="benefit"><h3>Débutant ou confirmé</h3><p className="muted">Un niveau affiché sur chaque boutique et chaque offre pour guider les acheteurs.</p></div>
          </div>
          <div className="panel" style={{ marginTop: 28 }}>
            <h2 style={{ fontSize: "1.4rem", marginBottom: 8 }}>Simple et lisible</h2>
            <p className="muted" style={{ marginBottom: 12 }}>Ouvrir une boutique est gratuit. {BRAND} prélève une commission uniquement quand vous vendez.</p>
            <table className="price-table">
              <tbody>
                <tr><td>Création de boutique</td><td><strong>Gratuit</strong></td></tr>
                <tr><td>Commission sur chaque vente (marché et titres payants)</td><td><strong>10&nbsp;%</strong></td></tr>
                <tr><td>Films et séries en accès gratuit</td><td><strong>Aucune commission</strong></td></tr>
                <tr><td>Soutien au créateur (don libre)</td><td><strong>5&nbsp;%</strong></td></tr>
                <tr><td>Retrait minimum</td><td><strong>5&nbsp;000 F CFA</strong></td></tr>
              </tbody>
            </table>
          </div>
          <div className="cta-band" style={{ marginTop: 36, marginBottom: 40 }}>
            <div>
              <h2>Créer ma boutique, c’est gratuit.</h2>
              <p>Aucune carte demandée à l’inscription. Publiez une première offre et encaissez en F CFA.</p>
            </div>
            <Link className="btn btn-primary btn-lg" href="/devenir-createur">Créer ma boutique gratuitement</Link>
          </div>
        </div>
      </section>
    </>
  );
}

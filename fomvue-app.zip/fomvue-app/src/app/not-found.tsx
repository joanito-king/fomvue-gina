import Link from "next/link";
export default function NotFound() {
  return (
    <div className="wrap" style={{ padding: "80px 0" }}>
      <div className="empty">
        <h1 style={{ fontSize: "1.8rem", marginBottom: 8 }}>Page introuvable</h1>
        <p>Cette page n’existe pas ou n’est plus disponible.</p>
        <Link className="btn btn-primary" style={{ marginTop: 16 }} href="/">Retour à l’accueil</Link>
      </div>
    </div>
  );
}

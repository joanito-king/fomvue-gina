import type { Metadata } from "next";
import "./globals.css";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { BRAND, SLOGAN, SLOGAN_EN } from "@/lib/constants";

export const metadata: Metadata = {
  title: { default: `${BRAND} — ${SLOGAN}`, template: `%s · ${BRAND}` },
  applicationName: BRAND,
  keywords: ["FOMVUE", "Fomvue", "créateurs IA", "films IA", "formations IA", SLOGAN, SLOGAN_EN],
  metadataBase: new URL(process.env.APP_URL || "https://fomvue.com"),
  openGraph: { siteName: BRAND, title: `${BRAND} — ${SLOGAN}`, description: `${SLOGAN} (${SLOGAN_EN}). Films, séries, formations et créations IA en F CFA.` },
  description: "FOMVUE — Regarder • Apprendre • Créer (Watch • Learn • Create). Boutiques de créateurs IA : scénarios, séries, prompts, services, formations et films IA, payables en F CFA par Wave, Orange Money, MTN, Moov ou carte.",
  icons: { icon: "/favicon.svg" },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        {/* eslint-disable-next-line @next/next/no-page-custom-font */}
        <link
          href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,560;0,9..144,700;1,9..144,560&family=Outfit:wght@400;500;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>
        <Header />
        <main>{children}</main>
        <Footer />
      </body>
    </html>
  );
}

import Link from "next/link";
import type { Prisma } from "@prisma/client";
import { prisma } from "@/lib/db";
import { CATEGORIES, catBySlug } from "@/lib/constants";
import { ProductCard } from "@/components/Cards";

export const metadata = { title: "Catalogue" };
type SP = Promise<Record<string, string | undefined>>;

export default async function Page({ searchParams }: { searchParams: SP }) {
  const sp = await searchParams;
  const cat = sp.cat ? catBySlug(sp.cat) : undefined;
  const q = (sp.q || "").trim();
  const where: Prisma.ProductWhereInput = { status: "PUBLISHED" };
  if (cat) where.category = cat.id;
  if (sp.niveau === "debutant") where.level = "DEBUTANT";
  if (sp.niveau === "confirme") where.level = "CONFIRME";
  if (q) where.OR = [{ title: { contains: q } }, { description: { contains: q } }, { shop: { name: { contains: q } } }];
  const orderBy: Prisma.ProductOrderByWithRelationInput =
    sp.tri === "prix-asc" ? { price: "asc" } : sp.tri === "prix-desc" ? { price: "desc" } : { createdAt: "desc" };
  const products = await prisma.product.findMany({ where, orderBy, include: { shop: true, reviews: { select: { stars: true } } }, take: 60 });
  const link = (patch: Record<string, string | undefined>) => {
    const p = new URLSearchParams(Object.entries({ ...sp, ...patch }).filter(([, v]) => v) as [string, string][]);
    return `/catalogue${p.size ? `?${p}` : ""}`;
  };
  return (
    <div className="wrap" style={{ paddingBottom: 60 }}>
      <div className="page-hero">
        <div className="crumbs"><Link href="/">Accueil</Link> · Marché</div>
        <h1>{cat ? cat.name : "Catalogue du marché"}</h1>
        <p className="muted">{cat ? cat.desc : "Scénarios, idées, prompts, services et formations de créateurs IA, en F CFA."}</p>
      </div>
      <div className="catalog-layout">
        <aside className="filters panel">
          <form action="/catalogue">
            {cat && <input type="hidden" name="cat" value={cat.slug} />}
            <div className="field" style={{ marginTop: 0 }}>
              <label htmlFor="q">Rechercher</label>
              <input id="q" name="q" defaultValue={q} placeholder="Titre, boutique…" />
            </div>
          </form>
          <h4 style={{ margin: "16px 0 8px" }}>Catégories</h4>
          <div style={{ display: "grid", gap: 4 }}>
            <Link className={`tab ${!cat ? "is-on" : ""}`} href={link({ cat: undefined })}>Toutes</Link>
            {CATEGORIES.map((c) => (
              <Link key={c.id} className={`tab ${cat?.id === c.id ? "is-on" : ""}`} href={link({ cat: c.slug })}>{c.name}</Link>
            ))}
          </div>
          <h4 style={{ margin: "16px 0 8px" }}>Niveau</h4>
          <div style={{ display: "grid", gap: 4 }}>
            <Link className={`tab ${!sp.niveau ? "is-on" : ""}`} href={link({ niveau: undefined })}>Tous</Link>
            <Link className={`tab ${sp.niveau === "debutant" ? "is-on" : ""}`} href={link({ niveau: "debutant" })}>Débutant</Link>
            <Link className={`tab ${sp.niveau === "confirme" ? "is-on" : ""}`} href={link({ niveau: "confirme" })}>Confirmé</Link>
          </div>
        </aside>
        <div>
          <div className="toolbar">
            <span className="muted">{products.length} résultat{products.length > 1 ? "s" : ""}{q ? ` pour « ${q} »` : ""}</span>
            <div style={{ display: "flex", gap: 6 }}>
              <Link className={`btn btn-sm ${!sp.tri ? "btn-primary" : "btn-outline"}`} href={link({ tri: undefined })}>Récents</Link>
              <Link className={`btn btn-sm ${sp.tri === "prix-asc" ? "btn-primary" : "btn-outline"}`} href={link({ tri: "prix-asc" })}>Prix ↑</Link>
              <Link className={`btn btn-sm ${sp.tri === "prix-desc" ? "btn-primary" : "btn-outline"}`} href={link({ tri: "prix-desc" })}>Prix ↓</Link>
            </div>
          </div>
          {products.length ? (
            <div className="product-grid">{products.map((p) => <ProductCard key={p.id} p={p} />)}</div>
          ) : (
            <div className="empty">Aucune création ne correspond. Essayez une autre recherche.</div>
          )}
        </div>
      </div>
    </div>
  );
}

import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { fcfa } from "@/lib/format";
import { buyFilmAction } from "@/app/actions/checkout";
import { Flash } from "@/components/Cards";
import { PayMethods } from "@/components/PayMethods";

export const metadata = { title: "Paiement du titre" };

export default async function Page({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<Record<string, string | undefined>> }) {
  const { id } = await params;
  const sp = await searchParams;
  const mode = sp.mode === "RENT" ? "RENT" : "BUY";
  await requireUser(`/regarder/${id}/payer?mode=${mode}`);
  const f = await prisma.film.findUnique({ where: { id }, include: { shop: true } });
  if (!f || f.access !== "PAID") notFound();
  const price = (mode === "RENT" ? f.rentPrice : f.buyPrice) ?? 0;
  return (
    <div className="wrap" style={{ paddingBottom: 60 }}>
      <div className="page-hero">
        <div className="crumbs"><Link href={`/regarder/${f.id}`}>← {f.title}</Link></div>
        <h1>{mode === "RENT" ? "Louer 48 h" : "Acheter le titre"}</h1>
        {(process.env.PAYMENT_PROVIDER || "mock") === "mock" && <p className="muted">Mode test : paiement simulé.</p>}
      </div>
      <Flash error={sp.error} />
      <div className="checkout-layout">
        <div className="panel">
          <div style={{ display: "flex", gap: 14 }}>
            <div style={{ background: f.poster, width: 84, height: 120, borderRadius: 14, flexShrink: 0 }} />
            <div>
              <strong>{f.title}</strong>
              <div className="tiny">{f.shop.name}</div>
              <p className="tiny" style={{ marginTop: 6 }}>{mode === "RENT" ? "Accès pendant 48 heures à partir du paiement." : "Accès illimité, depuis votre bibliothèque."}</p>
              <div className="price" style={{ marginTop: 6 }}>{fcfa(price)}</div>
            </div>
          </div>
          <div style={{ display: "flex", gap: 8, marginTop: 16 }}>
            {f.buyPrice ? <Link className={`btn btn-sm ${mode === "BUY" ? "btn-primary" : "btn-outline"}`} href={`?mode=BUY`}>Acheter {fcfa(f.buyPrice)}</Link> : null}
            {f.rentPrice ? <Link className={`btn btn-sm ${mode === "RENT" ? "btn-primary" : "btn-outline"}`} href={`?mode=RENT`}>Louer {fcfa(f.rentPrice)}</Link> : null}
          </div>
        </div>
        <form className="panel" action={buyFilmAction}>
          <h2 style={{ fontSize: "1.3rem", marginBottom: 14 }}>Moyen de paiement</h2>
          <input type="hidden" name="filmId" value={f.id} />
          <input type="hidden" name="mode" value={mode} />
          <PayMethods />
          <button className="btn btn-primary btn-lg btn-block" style={{ marginTop: 18 }} data-testid="pay-btn">Payer {fcfa(price)}</button>
        </form>
      </div>
    </div>
  );
}

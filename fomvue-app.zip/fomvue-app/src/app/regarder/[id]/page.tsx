import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { currentUser } from "@/lib/auth";
import { FILM_KINDS } from "@/lib/constants";
import { fcfa } from "@/lib/format";
import { hasFilmAccess } from "@/lib/services/catalog";
import { AccessBadges, Flash, ProductCard, ShopAvatar } from "@/components/Cards";
import { SupportButton } from "@/components/SupportButton";

type P = { params: Promise<{ id: string }>; searchParams: Promise<Record<string, string | undefined>> };

export async function generateMetadata({ params }: P) {
  const { id } = await params;
  const f = await prisma.film.findUnique({ where: { id } });
  return { title: f?.title ?? "Regarder" };
}

export default async function Page({ params, searchParams }: P) {
  const { id } = await params;
  const sp = await searchParams;
  const f = await prisma.film.findUnique({ where: { id }, include: { shop: true, episodes: { orderBy: { position: "asc" } } } });
  if (!f || f.status !== "PUBLISHED") notFound();
  const user = await currentUser();
  const unlocked = await hasFilmAccess(user?.id, f, user?.shop?.id);
  const related = await prisma.product.findMany({ where: { shopId: f.shopId, status: "PUBLISHED" }, take: 3, include: { shop: true, reviews: { select: { stars: true } } } });
  return (
    <div className="wrap" style={{ paddingBottom: 60 }}>
      <div className="page-hero" style={{ paddingBottom: 8 }}>
        <div className="crumbs"><Link href="/regarder">Regarder</Link> · {FILM_KINDS[f.kind]} · {f.title}</div>
      </div>
      <Flash error={sp.error} />
      <div className="watch-detail">
        <div className="watch-poster-lg" style={{ background: f.poster }}>
          <AccessBadges f={f} />
          <strong style={{ fontSize: "1.4rem", marginTop: 12 }}>{f.title}</strong>
        </div>
        <div>
          <p className="tiny">{FILM_KINDS[f.kind]} · {f.year} · {f.ageRating}{f.durationLabel && ` · ${f.durationLabel}`} · {f.views.toLocaleString("fr-FR")} vues</p>
          <h1 style={{ margin: "6px 0 12px" }}>{f.title}</h1>
          <p className="lead" style={{ marginLeft: 0 }}>{f.synopsis}</p>
          <div className="cta-row" style={{ margin: "18px 0 22px" }}>
            <Link className="btn btn-primary btn-lg" href={`/regarder/${f.id}/voir`}>{unlocked ? "Regarder" : "Regarder la bande-annonce"}</Link>
            {!unlocked && f.buyPrice ? <Link className="btn btn-outline" href={`/regarder/${f.id}/payer?mode=BUY`} data-testid="film-buy">Acheter {fcfa(f.buyPrice)}</Link> : null}
            {!unlocked && f.rentPrice ? <Link className="btn btn-outline" href={`/regarder/${f.id}/payer?mode=RENT`} data-testid="film-rent">Louer 48h {fcfa(f.rentPrice)}</Link> : null}
            <SupportButton shopId={f.shopId} shopName={f.shop.name} filmId={f.id} back={`/regarder/${f.id}`} userName={user?.name} />
          </div>
          <div className="panel" style={{ display: "flex", gap: 16, alignItems: "center", flexWrap: "wrap" }}>
            <ShopAvatar shop={f.shop} size={56} />
            <div style={{ flex: 1 }}>
              <div className="tiny">Créateur</div>
              <strong>{f.shop.flag} {f.shop.name}</strong>
              <div className="tiny">{f.shop.city}{f.shop.city && ", "}{f.shop.country} · {f.shop.tagline}</div>
            </div>
            <Link className="btn btn-outline" href={`/boutique/${f.shop.slug}`}>Voir la boutique du créateur</Link>
          </div>
          {f.episodes.length > 0 && (
            <>
              <h2 style={{ fontSize: "1.25rem", margin: "28px 0 8px" }}>Épisodes</h2>
              <div className="panel" style={{ padding: "8px 18px" }}>
                {f.episodes.map((e, i) => (
                  <div className="episode" key={e.id}>
                    <div className="ep-num">{String(i + 1).padStart(2, "0")}</div>
                    <div><strong>{e.title}</strong><div className="tiny">{e.recap}</div></div>
                    <div className="tiny">{e.durationMin} min</div>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      </div>
      {related.length > 0 && (
        <div style={{ marginTop: 36 }}>
          <h2 style={{ fontSize: "1.35rem", marginBottom: 8 }}>Aussi en vente chez ce créateur</h2>
          <p className="muted" style={{ marginBottom: 14 }}>Scénario, formation, pack personnages… pour aller plus loin que le visionnage.</p>
          <div className="product-grid">{related.map((p) => <ProductCard key={p.id} p={p} />)}</div>
        </div>
      )}
    </div>
  );
}

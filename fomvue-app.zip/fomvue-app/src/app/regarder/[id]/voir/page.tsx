import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { currentUser } from "@/lib/auth";
import { fcfa } from "@/lib/format";
import { hasFilmAccess } from "@/lib/services/catalog";
import { VideoPlayer } from "@/components/VideoPlayer";
import { SupportButton } from "@/components/SupportButton";

export const metadata = { title: "Lecture" };

export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const f = await prisma.film.findUnique({ where: { id }, include: { shop: true, episodes: { orderBy: { position: "asc" } } } });
  if (!f || f.status !== "PUBLISHED") notFound();
  const user = await currentUser();
  const unlocked = await hasFilmAccess(user?.id, f, user?.shop?.id);
  if (unlocked) await prisma.film.update({ where: { id: f.id }, data: { views: { increment: 1 } } });
  const access = user && f.access === "PAID" ? await prisma.filmAccess.findFirst({ where: { userId: user.id, filmId: f.id }, orderBy: { createdAt: "desc" } }) : null;
  return (
    <div className="wrap" style={{ padding: "22px 0 60px" }}>
      <div className="crumbs" style={{ marginBottom: 12 }}><Link href={`/regarder/${f.id}`}>← {f.title}</Link></div>
      {unlocked ? (
        <>
          <VideoPlayer url={f.videoUrl} title={f.title} />
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12, marginTop: 16, flexWrap: "wrap" }}>
            <div>
              <h1 style={{ fontSize: "1.6rem" }}>{f.title}</h1>
              <p className="tiny">
                {f.shop.flag} {f.shop.name}
                {access?.mode === "RENT" && access.expiresAt && ` · Location valable jusqu’au ${access.expiresAt.toLocaleString("fr-FR", { timeZone: "Africa/Dakar", day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })} (heure de Dakar)`}
              </p>
            </div>
            <SupportButton shopId={f.shopId} shopName={f.shop.name} filmId={f.id} back={`/regarder/${f.id}/voir`} userName={user?.name} label={f.access === "FREE" ? "Vous avez aimé ? Soutenez le créateur" : "Soutenir le créateur"} />
          </div>
        </>
      ) : (
        <div className="paywall" style={{ position: "relative", background: f.poster, borderRadius: 20, minHeight: 420, display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
          <div className="paywall-card">
            <h2 style={{ fontSize: "1.4rem" }}>{f.title}</h2>
            <p className="muted" style={{ margin: "8px 0 16px" }}>Ce titre est payant. Choisissez votre accès :</p>
            <div style={{ display: "grid", gap: 10 }}>
              {f.buyPrice ? <Link className="btn btn-primary btn-lg btn-block" href={`/regarder/${f.id}/payer?mode=BUY`}>Acheter · {fcfa(f.buyPrice)} (illimité)</Link> : null}
              {f.rentPrice ? <Link className="btn btn-outline btn-lg btn-block" href={`/regarder/${f.id}/payer?mode=RENT`}>Louer 48 h · {fcfa(f.rentPrice)}</Link> : null}
            </div>
            <p className="tiny" style={{ marginTop: 12 }}>Wave, Orange Money, MTN, Moov ou carte.</p>
          </div>
        </div>
      )}
    </div>
  );
}

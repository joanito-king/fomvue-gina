import Link from "next/link";
import { prisma } from "@/lib/db";
import { FILM_KINDS } from "@/lib/constants";
import { TitleCard } from "@/components/Cards";

export const metadata = { title: "Regarder" };

export default async function Page() {
  const films = await prisma.film.findMany({ where: { status: "PUBLISHED" }, include: { shop: true }, orderBy: { createdAt: "desc" } });
  const featured = films.find((f) => f.featured) ?? films[0];
  const rows = [
    { label: "Gratuit", list: films.filter((f) => f.access === "FREE") },
    { label: "Nouveautés", list: films.slice(0, 10) },
    { label: "Séries IA", list: films.filter((f) => f.kind === "SERIE") },
    { label: "Films IA", list: films.filter((f) => f.kind === "FILM") },
    { label: "Contes africains", list: films.filter((f) => f.kind === "CONTE") },
    { label: "Talk-shows", list: films.filter((f) => f.kind === "TALKSHOW") },
  ];
  if (!featured)
    return (
      <div className="wrap" style={{ padding: "60px 0" }}>
        <div className="empty">Aucun titre pour l’instant. Créateurs : publiez le vôtre depuis l’espace vendeur.</div>
      </div>
    );
  return (
    <div className="wrap" style={{ paddingBottom: 60 }}>
      <div className="watch-hero" style={{ background: featured.poster }}>
        <div className="watch-hero-inner">
          <div className="watch-kicker">À la une · {FILM_KINDS[featured.kind]}</div>
          <h1>{featured.title}</h1>
          <div className="watch-meta">
            <span className="watch-chip">{featured.year}</span>
            <span className="watch-chip">{featured.ageRating}</span>
            {featured.durationLabel && <span className="watch-chip">{featured.durationLabel}</span>}
            <span className="watch-chip">{featured.access === "FREE" ? "Gratuit" : "Payant"}</span>
          </div>
          <p className="lead">{featured.synopsis.slice(0, 220)}{featured.synopsis.length > 220 ? "…" : ""}</p>
          <div className="cta-row">
            <Link className="btn btn-primary btn-lg" href={`/regarder/${featured.id}/voir`}>Regarder</Link>
            <Link className="btn btn-outline btn-lg" href={`/regarder/${featured.id}`} style={{ background: "rgba(255,255,255,.12)", color: "#fff", borderColor: "rgba(255,255,255,.35)" }}>Plus d’infos</Link>
          </div>
        </div>
      </div>
      {rows.filter((r) => r.list.length).map((r) => (
        <section className="watch-row" key={r.label}>
          <h2>{r.label}</h2>
          <div className="watch-scroller">{r.list.map((f) => <TitleCard key={f.id} f={f} />)}</div>
        </section>
      ))}
    </div>
  );
}

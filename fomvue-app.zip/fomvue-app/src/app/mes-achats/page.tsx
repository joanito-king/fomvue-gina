import Link from "next/link";
import { prisma } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { KINDS, FILM_KINDS } from "@/lib/constants";
import { dateFr, fcfa } from "@/lib/format";

export const metadata = { title: "Mes achats" };

export default async function Page() {
  const user = await requireUser("/mes-achats");
  const [orders, films, tips, progress] = await Promise.all([
    prisma.order.findMany({ where: { buyerId: user.id }, include: { product: { include: { shop: true, _count: { select: { lessons: true } } } } }, orderBy: { createdAt: "desc" } }),
    prisma.filmAccess.findMany({ where: { userId: user.id }, include: { film: { include: { shop: true } } }, orderBy: { createdAt: "desc" } }),
    prisma.tip.findMany({ where: { senderId: user.id }, include: { shop: true }, orderBy: { createdAt: "desc" } }),
    prisma.lessonProgress.findMany({ where: { userId: user.id }, include: { lesson: { select: { productId: true } } } }),
  ]);
  const done = (pid: string) => progress.filter((p) => p.lesson.productId === pid).length;
  const now = new Date();
  return (
    <div className="wrap" style={{ paddingBottom: 60 }}>
      <div className="page-hero">
        <div className="crumbs"><Link href="/">Accueil</Link> · Mes achats</div>
        <h1>Ma bibliothèque</h1>
        <p className="muted">Tous vos achats restent accessibles ici, pour toujours.</p>
      </div>
      <h2 style={{ fontSize: "1.3rem", margin: "8px 0 12px" }}>Produits et formations</h2>
      {orders.length === 0 && <div className="empty">Pas encore d’achat. <Link className="link-arrow" href="/catalogue">Explorer le marché →</Link></div>}
      <div style={{ display: "grid", gap: 12 }}>
        {orders.map((o) => {
          const p = o.product;
          const total = p._count.lessons;
          const pct = total ? Math.round((done(p.id) / total) * 100) : 0;
          return (
            <div className="lib-item" key={o.id}>
              <div style={{ background: p.coverColor, width: 64, height: 64, borderRadius: 12, flexShrink: 0 }} />
              <div style={{ flex: 1 }}>
                <strong>{p.title}</strong>
                <div className="tiny">{KINDS[p.kind]} · {p.shop.name} · {o.number} · {dateFr(o.createdAt)} · {fcfa(o.amount)}</div>
                {p.kind === "FORMATION" && total > 0 && (
                  <div style={{ marginTop: 6, maxWidth: 260 }}>
                    <div className="progress-bar"><span style={{ width: `${pct}%` }} /></div>
                    <div className="tiny">{pct} % terminé</div>
                  </div>
                )}
              </div>
              {p.kind === "FORMATION" ? (
                <Link className="btn btn-primary btn-sm" href={`/apprendre/${p.id}`}>{pct > 0 ? "Continuer" : "Commencer"}</Link>
              ) : p.kind === "SERVICE" || p.kind === "COACHING" ? (
                <span className="tiny">Le créateur vous contacte sous 48 h</span>
              ) : (
                <a className="btn btn-primary btn-sm" href={`/api/download/${p.id}`}>Télécharger</a>
              )}
            </div>
          );
        })}
      </div>
      <h2 style={{ fontSize: "1.3rem", margin: "28px 0 12px" }}>Films et séries</h2>
      {films.length === 0 && <div className="empty">Aucun titre acheté ou loué. <Link className="link-arrow" href="/regarder">Ouvrir Regarder →</Link></div>}
      <div style={{ display: "grid", gap: 12 }}>
        {films.map((a) => {
          const expired = a.mode === "RENT" && a.expiresAt && a.expiresAt < now;
          return (
            <div className="lib-item" key={a.id}>
              <div style={{ background: a.film.poster, width: 48, height: 68, borderRadius: 10, flexShrink: 0 }} />
              <div style={{ flex: 1 }}>
                <strong>{a.film.title}</strong>
                <div className="tiny">
                  {FILM_KINDS[a.film.kind]} · {a.film.shop.name} · {a.mode === "RENT" ? (expired ? "Location expirée" : `Location jusqu’au ${a.expiresAt!.toLocaleString("fr-FR", { timeZone: "Africa/Dakar", day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })}`) : "Acheté"}
                </div>
              </div>
              <Link className={`btn btn-sm ${expired ? "btn-outline" : "btn-primary"}`} href={expired ? `/regarder/${a.filmId}` : `/regarder/${a.filmId}/voir`}>{expired ? "Relouer" : "Regarder"}</Link>
            </div>
          );
        })}
      </div>
      {tips.length > 0 && (
        <>
          <h2 style={{ fontSize: "1.3rem", margin: "28px 0 12px" }}>Mes soutiens</h2>
          <table>
            <thead><tr><th>Date</th><th>Créateur</th><th>Montant</th></tr></thead>
            <tbody>{tips.map((t) => <tr key={t.id}><td>{dateFr(t.createdAt)}</td><td>{t.shop.name}</td><td>{fcfa(t.amount)}</td></tr>)}</tbody>
          </table>
        </>
      )}
    </div>
  );
}

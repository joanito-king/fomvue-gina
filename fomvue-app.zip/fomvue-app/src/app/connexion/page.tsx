import Link from "next/link";
import { loginAction } from "@/app/actions/auth";
import { Flash } from "@/components/Cards";

export const metadata = { title: "Connexion" };
type SP = Promise<Record<string, string | undefined>>;

export default async function Page({ searchParams }: { searchParams: SP }) {
  const sp = await searchParams;
  return (
    <div className="wrap">
      <div className="panel auth-card">
        <h1 style={{ fontSize: "1.8rem" }}>Connexion</h1>
        <p className="muted">Retrouvez vos achats, votre boutique et vos films.</p>
        <Flash error={sp.error} />
        <form action={loginAction}>
          <input type="hidden" name="next" value={sp.next ?? "/"} />
          <div className="field"><label htmlFor="email">E-mail</label><input id="email" name="email" type="email" required autoComplete="email" /></div>
          <div className="field"><label htmlFor="password">Mot de passe</label><input id="password" name="password" type="password" required autoComplete="current-password" /></div>
          <button className="btn btn-primary btn-lg btn-block" style={{ marginTop: 18 }} type="submit">Se connecter</button>
        </form>
        <p className="tiny" style={{ marginTop: 14, textAlign: "center" }}>
          Pas encore de compte ? <Link className="link-arrow" href={`/inscription${sp.next ? `?next=${encodeURIComponent(sp.next)}` : ""}`}>Créer un compte</Link>
        </p>
        {process.env.NODE_ENV !== "production" || process.env.SHOW_DEMO_ACCOUNTS === "1" ? (
          <div className="demo-box">
            <strong>Comptes de démonstration</strong> (mot de passe <code>demo1234</code>)<br />
            Admin : gina@fomvue.com · Créatrice : awa@fomvue.com · Acheteur : moussa@exemple.sn
          </div>
        ) : null}
      </div>
    </div>
  );
}

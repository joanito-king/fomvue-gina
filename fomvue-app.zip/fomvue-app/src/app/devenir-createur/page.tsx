import Link from "next/link";
import { redirect } from "next/navigation";
import { currentUser } from "@/lib/auth";
import { becomeCreatorAction } from "@/app/actions/auth";

export const metadata = { title: "Devenir créateur" };

export default async function Page() {
  const user = await currentUser();
  if (user?.shop) redirect("/vendeur");
  return (
    <div className="wrap" style={{ padding: "40px 0 80px" }}>
      <div className="hero-grid" style={{ alignItems: "start" }}>
        <div>
          <div className="eyebrow"><span className="eyebrow-dot" /> Débutant ou confirmé</div>
          <h1 style={{ fontSize: "clamp(2rem,4vw,3rem)", margin: "10px 0" }}>Vendez vos créations IA depuis votre propre boutique</h1>
          <p className="lead">Scénarios, séries, idées, prompts, templates, ebooks, services sur commande, coaching, formations et licences. Publiez aussi vos films dans Regarder et recevez des soutiens.</p>
          <div className="steps" style={{ marginTop: 20, gridTemplateColumns: "1fr" }}>
            <div className="step"><div className="step-num">1</div><h3>Créez votre boutique</h3><p className="muted">Nom, logo, couleurs, adresse nom.fomvue.com.</p></div>
            <div className="step"><div className="step-num">2</div><h3>Publiez une offre</h3><p className="muted">Prix en F CFA, fichier livré automatiquement.</p></div>
            <div className="step"><div className="step-num">3</div><h3>Encaissez</h3><p className="muted">Retraits Wave / Orange Money dès 5 000 F CFA.</p></div>
          </div>
        </div>
        <div className="panel">
          {user ? (
            <form action={becomeCreatorAction}>
              <h2 style={{ fontSize: "1.3rem" }}>Ouvrir ma boutique</h2>
              <p className="muted">Connecté en tant que {user.name}.</p>
              <div className="field"><label htmlFor="shopName">Nom de la boutique</label><input id="shopName" name="shopName" required placeholder="Ex. Studio Awa" /></div>
              <button className="btn btn-primary btn-lg btn-block" style={{ marginTop: 16 }}>Créer ma boutique gratuitement</button>
            </form>
          ) : (
            <>
              <h2 style={{ fontSize: "1.3rem" }}>C’est gratuit</h2>
              <p className="muted" style={{ margin: "8px 0 16px" }}>Commission de 10 % uniquement quand vous vendez.</p>
              <Link className="btn btn-primary btn-lg btn-block" href="/inscription?createur=1">Créer ma boutique</Link>
              <Link className="btn btn-outline btn-block" style={{ marginTop: 10 }} href="/connexion?next=/devenir-createur">J’ai déjà un compte</Link>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { KINDS } from "@/lib/constants";
import { fcfa } from "@/lib/format";
import { buyProductAction } from "@/app/actions/checkout";
import { Flash } from "@/components/Cards";
import { PayMethods } from "@/components/PayMethods";

export const metadata = { title: "Paiement" };
type P = { params: Promise<{ id: string }>; searchParams: Promise<Record<string, string | undefined>> };

export default async function Page({ params, searchParams }: P) {
  const { id } = await params;
  const sp = await searchParams;
  await requireUser(`/checkout/${id}`);
  const p = await prisma.product.findUnique({ where: { id }, include: { shop: true } });
  if (!p || p.status !== "PUBLISHED") notFound();
  const mock = (process.env.PAYMENT_PROVIDER || "mock") === "mock";
  return (
    <div className="wrap" style={{ paddingBottom: 60 }}>
      <div className="page-hero">
        <div className="crumbs"><Link href={`/produit/${p.id}`}>← Retour à l’offre</Link></div>
        <h1>Paiement</h1>
        {mock && <p className="muted">Mode test : le paiement est simulé, aucun argent n’est débité.</p>}
      </div>
      <Flash error={sp.error} />
      <div className="checkout-layout">
        <div className="panel">
          <h2 style={{ fontSize: "1.3rem", marginBottom: 14 }}>Votre commande</h2>
          <div style={{ display: "flex", gap: 14 }}>
            <div style={{ background: p.coverColor, width: 84, height: 84, borderRadius: 14, flexShrink: 0 }} />
            <div>
              <strong>{p.title}</strong>
              <div className="tiny">{p.shop.name} · {KINDS[p.kind]}</div>
              <div className="price" style={{ marginTop: 6 }}>{fcfa(p.price)}</div>
            </div>
          </div>
          <hr style={{ border: 0, borderTop: "1px solid var(--line)", margin: "18px 0" }} />
          <div style={{ display: "flex", justifyContent: "space-between" }}><span className="muted">Sous-total</span><span>{fcfa(p.price)}</span></div>
          <div style={{ display: "flex", justifyContent: "space-between", marginTop: 6 }}><span className="muted">Frais</span><span>0&nbsp;F CFA</span></div>
          <div style={{ display: "flex", justifyContent: "space-between", marginTop: 10, fontWeight: 700, fontSize: "1.1rem" }}><span>Total</span><span>{fcfa(p.price)}</span></div>
        </div>
        <form className="panel" action={buyProductAction}>
          <h2 style={{ fontSize: "1.3rem", marginBottom: 14 }}>Moyen de paiement</h2>
          <input type="hidden" name="productId" value={p.id} />
          <PayMethods />
          <button className="btn btn-primary btn-lg btn-block" type="submit" style={{ marginTop: 18 }} data-testid="pay-btn">Payer {fcfa(p.price)}</button>
        </form>
      </div>
    </div>
  );
}

import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { currentUser } from "@/lib/auth";
import { catById, KINDS } from "@/lib/constants";
import { fcfa, stars } from "@/lib/format";
import { publicUrl } from "@/lib/storage";
import { ownsProduct } from "@/lib/services/catalog";
import { avgRating, LevelBadge, ProductCard } from "@/components/Cards";
import { SupportButton } from "@/components/SupportButton";

type P = { params: Promise<{ id: string }> };

export async function generateMetadata({ params }: P) {
  const { id } = await params;
  const p = await prisma.product.findUnique({ where: { id } });
  return { title: p?.title ?? "Produit" };
}

export default async function Page({ params }: P) {
  const { id } = await params;
  const p = await prisma.product.findUnique({
    where: { id },
    include: { shop: true, reviews: { orderBy: { createdAt: "desc" } }, lessons: { orderBy: { position: "asc" } }, _count: { select: { orders: true } } },
  });
  const user = await currentUser();
  if (!p || (p.status !== "PUBLISHED" && p.shop.ownerId !== user?.id && user?.role !== "ADMIN")) notFound();
  const owned = await ownsProduct(user?.id, p.id);
  const cat = catById(p.category);
  const related = await prisma.product.findMany({
    where: { category: p.category, status: "PUBLISHED", NOT: { id: p.id } },
    take: 4,
    include: { shop: true, reviews: { select: { stars: true } } },
  });
  const rating = avgRating(p.reviews);
  const cover = publicUrl(p.coverKey);
  const sections = p.lessons.reduce<Record<string, typeof p.lessons>>((acc, l) => ((acc[l.section] ||= []).push(l), acc), {});
  const isService = p.kind === "SERVICE" || p.kind === "COACHING";
  return (
    <div className="wrap" style={{ paddingBottom: 60 }}>
      <div className="crumbs" style={{ paddingTop: 22 }}>
        <Link href="/">Accueil</Link> · <Link href={`/catalogue?cat=${cat.slug}`}>{cat.name}</Link> · {p.title}
      </div>
      {p.status !== "PUBLISHED" && <div className="alert alert-error">Statut : {p.status} — visible uniquement par vous.</div>}
      <div className="product-layout">
        <div>
          <div className="product-visual" style={{ background: p.coverColor, position: "relative", overflow: "hidden" }}>
            {cover && <img className="cover-img" src={cover} alt="" />}
            <span className="badge-cat" style={{ position: "relative" }}>{cat.name} · {KINDS[p.kind]}</span>
            <h2 style={{ fontSize: "1.8rem", marginTop: 8, position: "relative" }}>{p.title}</h2>
          </div>
          <h2 style={{ margin: "28px 0 10px" }}>Description</h2>
          <p style={{ whiteSpace: "pre-line" }}>{p.description}</p>
          {p.includes && (
            <>
              <h3 style={{ fontFamily: "var(--font)", letterSpacing: 0, margin: "22px 0 10px" }}>Ce qui est inclus</h3>
              <ul style={{ paddingLeft: 18, color: "var(--ink-soft)" }}>
                {p.includes.split("\n").filter(Boolean).map((i) => <li key={i} style={{ margin: "6px 0" }}>{i}</li>)}
              </ul>
            </>
          )}
          {p.lessons.length > 0 && (
            <>
              <h3 style={{ fontFamily: "var(--font)", letterSpacing: 0, margin: "22px 0 10px" }}>Programme · {p.lessons.length} leçons · {p.lessons.reduce((s, l) => s + l.durationMin, 0)} min</h3>
              <div className="curric">
                {Object.entries(sections).map(([sec, ls]) => (
                  <details className="curric-sec" key={sec} open>
                    <summary>{sec}<span className="tiny">{ls.length} leçons</span></summary>
                    {ls.map((l) => <div className="lesson" key={l.id}><span>▸ {l.title}</span><span className="tiny">{l.durationMin} min</span></div>)}
                  </details>
                ))}
              </div>
            </>
          )}
        </div>
        <aside className="buy-box">
          <div className="tiny">Proposé par <Link className="link-arrow" href={`/boutique/${p.shop.slug}`}>{p.shop.flag} {p.shop.name}</Link></div>
          <div className="price" style={{ margin: "8px 0" }}>{fcfa(p.price)}</div>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 12 }}>
            <LevelBadge level={p.level} />
            {rating > 0 && <span className="stars">{stars(rating)} {rating.toFixed(1).replace(".", ",")} ({p.reviews.length} avis)</span>}
          </div>
          {owned && !isService ? (
            <>
              <Link className="btn btn-teal btn-lg btn-block" href={p.kind === "FORMATION" ? `/apprendre/${p.id}` : "/mes-achats"}>
                {p.kind === "FORMATION" ? "Continuer la formation" : "Dans ma bibliothèque"}
              </Link>
              <p className="tiny" style={{ marginTop: 10, textAlign: "center" }}>Vous avez déjà accès à ce produit.</p>
            </>
          ) : (
            <>
              <Link className="btn btn-primary btn-lg btn-block" href={`/checkout/${p.id}`} data-testid="buy-btn">
                {isService ? "Commander" : "Acheter"}
              </Link>
              <p className="tiny" style={{ marginTop: 10, textAlign: "center" }}>Wave, Orange Money, MTN, Moov ou carte · accès immédiat</p>
            </>
          )}
          <hr style={{ border: 0, borderTop: "1px solid var(--line)", margin: "16px 0" }} />
          <p className="tiny" style={{ marginBottom: 10 }}>{p._count.orders.toLocaleString("fr-FR")} ventes sur cette offre.</p>
          <SupportButton shopId={p.shopId} shopName={p.shop.name} back={`/produit/${p.id}`} userName={user?.name} />
        </aside>
      </div>
      <div className="reviews">
        <h2>Avis d’acheteurs</h2>
        {p.reviews.length === 0 && <p className="muted">Pas encore d’avis.</p>}
        {p.reviews.map((r) => (
          <article className="review" key={r.id}>
            <strong>{r.name}</strong> <span className="tiny">· {r.city}</span>
            <div className="stars">{stars(r.stars)}</div>
            <p style={{ marginTop: 6 }}>{r.text}</p>
          </article>
        ))}
        {related.length > 0 && (
          <>
            <h2 style={{ marginTop: 36 }}>Dans la même catégorie</h2>
            <div className="product-grid" style={{ marginTop: 16 }}>{related.map((r) => <ProductCard key={r.id} p={r} />)}</div>
          </>
        )}
      </div>
    </div>
  );
}

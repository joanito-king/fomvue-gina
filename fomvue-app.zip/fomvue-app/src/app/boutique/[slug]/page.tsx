import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { currentUser } from "@/lib/auth";
import { fcfa, dateFr, shopHost } from "@/lib/format";
import { publicUrl } from "@/lib/storage";
import { Flash, LevelBadge, ProductCard, ShopAvatar, TitleCard } from "@/components/Cards";
import { SupportButton } from "@/components/SupportButton";

type P = { params: Promise<{ slug: string }>; searchParams: Promise<Record<string, string | undefined>> };

export async function generateMetadata({ params }: P) {
  const { slug } = await params;
  const shop = await prisma.shop.findUnique({ where: { slug } });
  return { title: shop?.name ?? "Boutique" };
}

export default async function Page({ params, searchParams }: P) {
  const { slug } = await params;
  const sp = await searchParams;
  const shop = await prisma.shop.findUnique({
    where: { slug },
    include: {
      products: { where: { status: "PUBLISHED" }, orderBy: { createdAt: "desc" }, include: { reviews: { select: { stars: true } } } },
      films: { where: { status: "PUBLISHED" }, orderBy: { createdAt: "desc" } },
      tips: { where: { isPublic: true }, orderBy: { createdAt: "desc" }, take: 6 },
      _count: { select: { orders: true } },
    },
  });
  if (!shop) notFound();
  const user = await currentUser();
  const banner = publicUrl(shop.bannerKey);
  return (
    <div className="wrap" style={{ paddingBottom: 60 }}>
      <div className="crumbs" style={{ paddingTop: 22 }}><Link href="/">Accueil</Link> · <Link href="/catalogue">Marché</Link> · {shop.name}</div>
      <Flash error={sp.error} />
      <div className="shop-banner" style={{ background: banner ? `url(${banner}) center/cover` : `linear-gradient(120deg, ${shop.color}, var(--footer-bg))` }}>
        <div className="shop-avatar" style={{ padding: 0, overflow: "hidden" }}><ShopAvatar shop={shop} size={92} /></div>
      </div>
      <div className="shop-head">
        <div>
          <div className="shop-url">{shopHost(shop.slug)}</div>
          <h1 style={{ marginTop: 8 }}>{shop.name}</h1>
          <p className="muted">{shop.flag} {shop.city}{shop.city && ", "}{shop.country} · {shop.tagline}</p>
          <div style={{ display: "flex", gap: 8, alignItems: "center", marginTop: 8, flexWrap: "wrap" }}>
            <LevelBadge level={shop.level} />
            <span className="tiny">{shop._count.orders.toLocaleString("fr-FR")} ventes · {shop.products.length} offres · {shop.films.length} titres</span>
          </div>
          {shop.bio && <p style={{ maxWidth: "62ch", marginTop: 14 }}>{shop.bio}</p>}
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 8, alignItems: "flex-end" }}>
          <SupportButton shopId={shop.id} shopName={shop.name} back={`/boutique/${shop.slug}`} userName={user?.name} />
          {user?.shop?.id === shop.id && <Link className="btn btn-ghost" href="/vendeur/boutique">Personnaliser la boutique</Link>}
        </div>
      </div>
      <h2 style={{ margin: "8px 0 16px" }}>Dans la boutique</h2>
      {shop.products.length ? (
        <div className="product-grid">{shop.products.map((p) => <ProductCard key={p.id} p={{ ...p, shop }} />)}</div>
      ) : (
        <div className="empty">Pas encore d’offre.</div>
      )}
      {shop.films.length > 0 && (
        <section className="watch-row" style={{ marginTop: 32 }}>
          <h2>À regarder</h2>
          <div className="watch-scroller">{shop.films.map((f) => <TitleCard key={f.id} f={{ ...f, shop }} />)}</div>
        </section>
      )}
      <div style={{ margin: "32px 0 0", maxWidth: 720 }}>
        <h2 style={{ fontSize: "1.3rem", marginBottom: 6 }}>Ils ont soutenu</h2>
        {shop.tips.length ? (
          <div className="support-list">
            {shop.tips.map((t) => (
              <div className="support-item" key={t.id}>
                <div className="avatar" style={{ position: "static", width: 44, height: 44, borderWidth: 0, fontSize: ".9rem", background: "var(--accent)" }}>♥</div>
                <div>
                  <strong>{t.senderName}</strong>
                  {t.message && <p className="tiny" style={{ marginTop: 2 }}>« {t.message} »</p>}
                  <div className="tiny">{dateFr(t.createdAt)}</div>
                </div>
                <strong style={{ color: "var(--accent)" }}>{fcfa(t.amount)}</strong>
              </div>
            ))}
          </div>
        ) : (
          <p className="muted">Soyez le premier à soutenir ce créateur.</p>
        )}
      </div>
    </div>
  );
}

import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { prisma } from "@/lib/db";
import { requireUser } from "@/lib/auth";
import { ownsProduct } from "@/lib/services/catalog";
import { toggleLessonAction } from "@/app/actions/learn";
import { VideoPlayer } from "@/components/VideoPlayer";

export const metadata = { title: "Formation" };

export default async function Page({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<Record<string, string | undefined>> }) {
  const { id } = await params;
  const sp = await searchParams;
  const user = await requireUser(`/apprendre/${id}`);
  const p = await prisma.product.findUnique({ where: { id }, include: { shop: true, lessons: { orderBy: { position: "asc" } } } });
  if (!p) notFound();
  if (!(await ownsProduct(user.id, p.id))) redirect(`/produit/${p.id}`);
  const done = new Set((await prisma.lessonProgress.findMany({ where: { userId: user.id, lessonId: { in: p.lessons.map((l) => l.id) } } })).map((x) => x.lessonId));
  const current = p.lessons.find((l) => l.id === sp.lecon) ?? p.lessons.find((l) => !done.has(l.id)) ?? p.lessons[0];
  const idx = current ? p.lessons.indexOf(current) : -1;
  const pct = p.lessons.length ? Math.round((done.size / p.lessons.length) * 100) : 0;
  return (
    <div className="wrap" style={{ padding: "22px 0 60px" }}>
      <div className="crumbs" style={{ marginBottom: 12 }}><Link href="/mes-achats">← Ma bibliothèque</Link> · {p.title}</div>
      <div className="course-layout">
        <div>
          {current ? (
            <>
              {current.videoUrl ? <VideoPlayer url={current.videoUrl} title={current.title} /> : <div className="video-frame" style={{ display: "grid", placeItems: "center", color: "#fff", background: p.coverColor }}><strong style={{ fontSize: "1.4rem", padding: 20, textAlign: "center" }}>{current.title}</strong></div>}
              <h1 style={{ fontSize: "1.5rem", margin: "16px 0 6px" }}>{current.title}</h1>
              <p className="tiny">{current.section} · {current.durationMin} min</p>
              <p style={{ marginTop: 12, whiteSpace: "pre-line" }}>{current.content}</p>
              <div style={{ display: "flex", gap: 8, marginTop: 18, flexWrap: "wrap" }}>
                {idx > 0 && <Link className="btn btn-outline" href={`?lecon=${p.lessons[idx - 1]!.id}`}>← Précédente</Link>}
                <form action={toggleLessonAction}>
                  <input type="hidden" name="lessonId" value={current.id} />
                  <button className={`btn ${done.has(current.id) ? "btn-outline" : "btn-teal"}`}>{done.has(current.id) ? "✓ Terminée (annuler)" : "Marquer comme terminée"}</button>
                </form>
                {idx < p.lessons.length - 1 && <Link className="btn btn-primary" href={`?lecon=${p.lessons[idx + 1]!.id}`}>Suivante →</Link>}
              </div>
            </>
          ) : (
            <div className="empty">Le créateur n’a pas encore publié de leçon.</div>
          )}
        </div>
        <aside className="panel">
          <strong>{p.title}</strong>
          <div className="tiny">{p.shop.name}</div>
          <div className="progress-bar" style={{ margin: "10px 0 4px" }}><span style={{ width: `${pct}%` }} /></div>
          <div className="tiny">{done.size}/{p.lessons.length} leçons · {pct} %</div>
          <div className="chapters" style={{ marginTop: 12 }}>
            {p.lessons.map((l, i) => (
              <Link key={l.id} className={`chapter ${l.id === current?.id ? "is-on" : ""}`} href={`?lecon=${l.id}`}>
                <span>{done.has(l.id) ? "✓" : i + 1}</span> <span style={{ flex: 1 }}>{l.title}</span> <span className="tiny">{l.durationMin} min</span>
              </Link>
            ))}
          </div>
        </aside>
      </div>
    </div>
  );
}

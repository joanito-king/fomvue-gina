import { notFound, redirect } from "next/navigation";
import { prisma } from "@/lib/db";
import { PAY_METHODS } from "@/lib/constants";
import { fcfa } from "@/lib/format";
import { mockPayAction } from "@/app/actions/mockpay";
import { PayLogo } from "@/components/Cards";

export const metadata = { title: "Validation du paiement (test)" };

export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if ((process.env.PAYMENT_PROVIDER || "mock") !== "mock") notFound();
  const pay = await prisma.payment.findUnique({ where: { id } });
  if (!pay) notFound();
  if (pay.status !== "PENDING") redirect(`/paiement/retour/${pay.id}`);
  const m = PAY_METHODS.find((x) => x.id === pay.method) ?? PAY_METHODS[0];
  const what = pay.purpose === "TIP" ? "Soutien au créateur" : pay.purpose === "FILM" ? (pay.filmMode === "RENT" ? "Location 48 h" : "Achat de titre") : "Achat sur Fomvue";
  return (
    <div className="wrap" style={{ padding: "40px 0 80px" }}>
      <p className="muted" style={{ textAlign: "center", marginBottom: 18 }}>
        <span className="status status-PENDING">MODE TEST</span> Simulation de l’écran du prestataire de paiement — aucun débit réel.
      </p>
      <div className="mock-phone">
        <div className="screen">
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
            <PayLogo m={m} /> <strong>{m.label}</strong>
          </div>
          <p className="tiny">Demande de paiement de</p>
          <p className="tiny"><strong>Fomvue</strong> · réf. {pay.reference}</p>
          <div className="price" style={{ fontSize: "2rem", margin: "14px 0 4px" }}>{fcfa(pay.amount)}</div>
          <p className="muted tiny">{what}{pay.payerPhone ? ` · ${pay.payerPhone}` : ""}</p>
          <form action={mockPayAction} style={{ marginTop: 18, display: "grid", gap: 8 }}>
            <input type="hidden" name="paymentId" value={pay.id} />
            <button className="btn btn-primary btn-lg btn-block" name="outcome" value="success" data-testid="mock-confirm">Confirmer le paiement</button>
            <button className="btn btn-outline btn-block" name="outcome" value="fail">Refuser / échec</button>
          </form>
        </div>
        <p className="tiny" style={{ color: "#b4b0c0", textAlign: "center", marginTop: 14 }}>En production, cette étape se passe chez PayDunya ou CinetPay.</p>
      </div>
    </div>
  );
}

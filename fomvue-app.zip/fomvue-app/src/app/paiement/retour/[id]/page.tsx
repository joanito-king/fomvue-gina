import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { fcfa } from "@/lib/format";

export const metadata = { title: "Paiement" };

export default async function Page({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<Record<string, string | undefined>> }) {
  const { id } = await params;
  const sp = await searchParams;
  const pay = await prisma.payment.findUnique({
    where: { id },
    include: { order: { include: { product: true } }, filmAccess: { include: { film: true } }, tip: { include: { shop: true } } },
  });
  if (!pay) notFound();
  // Retour "annulé" : on n'écrit rien en base (seul le webhook fait foi), on adapte juste l'affichage.
  if (pay.status === "PENDING" && sp.annule === "1") pay.status = "CANCELLED";
  const ok = pay.status === "SUCCEEDED";
  return (
    <div className="wrap" style={{ padding: "40px 0 80px", maxWidth: 640 }}>
      <div className="panel success-box">
        {ok ? <div className="check">✓</div> : <div className="check" style={{ background: pay.status === "PENDING" ? "var(--accent)" : "#b42318" }}>{pay.status === "PENDING" ? "…" : "×"}</div>}
        <h1>{ok ? (pay.purpose === "TIP" ? "Merci pour votre soutien !" : "Paiement confirmé") : pay.status === "PENDING" ? "Paiement en attente" : "Paiement non abouti"}</h1>
        <p className="muted" style={{ margin: "10px 0 18px" }}>
          Réf. <strong>{pay.reference}</strong> · {fcfa(pay.amount)}
          {pay.order && <> · Commande <strong>{pay.order.number}</strong></>}
        </p>
        {ok && pay.order && <p>« {pay.order.product.title} » a été ajouté à votre bibliothèque.</p>}
        {ok && pay.filmAccess && (
          <p>
            {pay.filmAccess.mode === "RENT" ? "Location active pendant 48 h" : "Titre acheté, accès illimité"} : « {pay.filmAccess.film.title} ».
          </p>
        )}
        {ok && pay.tip && <p>{pay.tip.shop.name} a bien reçu votre soutien. 💛</p>}
        {pay.status === "PENDING" && <p>Validez la demande sur votre téléphone, puis actualisez cette page.</p>}
        {(pay.status === "FAILED" || pay.status === "CANCELLED") && <p>Aucun montant n’a été débité. Vous pouvez réessayer.</p>}
        <div style={{ display: "flex", gap: 10, justifyContent: "center", marginTop: 22, flexWrap: "wrap" }}>
          {pay.order && (pay.order.product.kind === "FORMATION" ? <Link className="btn btn-primary" href={`/apprendre/${pay.order.productId}`}>Commencer la formation</Link> : <Link className="btn btn-primary" href="/mes-achats">Voir ma bibliothèque</Link>)}
          {pay.filmAccess && <Link className="btn btn-primary" href={`/regarder/${pay.filmAccess.filmId}/voir`}>Regarder maintenant</Link>}
          {pay.tip && <Link className="btn btn-primary" href={`/boutique/${pay.tip.shop.slug}`}>Retour à la boutique</Link>}
          {pay.status === "PENDING" && <Link className="btn btn-outline" href={`/paiement/retour/${pay.id}`}>Actualiser</Link>}
          <Link className="btn btn-outline" href="/catalogue">Continuer à explorer</Link>
        </div>
      </div>
    </div>
  );
}

import { requireCreator } from "@/lib/auth";
import { VendorShell } from "@/components/VendorShell";
import { ProductForm } from "@/components/ProductForm";

export const metadata = { title: "Nouveau produit" };

export default async function Page({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  const { shop } = await requireCreator();
  return (
    <VendorShell shop={shop} active="produits" sp={sp}>
      <h2 style={{ fontSize: "1.3rem", marginBottom: 12 }}>Nouveau produit</h2>
      <ProductForm />
    </VendorShell>
  );
}

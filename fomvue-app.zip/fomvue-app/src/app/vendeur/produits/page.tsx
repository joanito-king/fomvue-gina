import Link from "next/link";
import { prisma } from "@/lib/db";
import { requireCreator } from "@/lib/auth";
import { KINDS } from "@/lib/constants";
import { fcfa } from "@/lib/format";
import { deleteProductAction } from "@/app/actions/vendor";
import { VendorShell } from "@/components/VendorShell";

export const metadata = { title: "Mes produits" };
const ST: Record<string, string> = { PUBLISHED: "Publié", DRAFT: "Brouillon", PENDING: "En revue", REJECTED: "Refusé" };

export default async function Page({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  const { shop } = await requireCreator();
  const products = await prisma.product.findMany({ where: { shopId: shop.id }, orderBy: { createdAt: "desc" }, include: { _count: { select: { orders: true, lessons: true } } } });
  return (
    <VendorShell shop={shop} active="produits" sp={sp}>
      <div className="toolbar">
        <h2 style={{ fontSize: "1.3rem" }}>Mes produits ({products.length})</h2>
        <Link className="btn btn-primary" href="/vendeur/produits/nouveau" data-testid="new-product">+ Nouveau produit</Link>
      </div>
      <div className="panel">
        {products.length === 0 ? (
          <p className="muted">Aucun produit. Commencez par un pack de prompts ou un scénario : c’est le plus simple à vendre.</p>
        ) : (
          <table>
            <thead><tr><th>Produit</th><th>Type</th><th>Prix</th><th>Ventes</th><th>Statut</th><th></th></tr></thead>
            <tbody>
              {products.map((p) => (
                <tr key={p.id}>
                  <td><Link className="link-arrow" href={`/produit/${p.id}`}>{p.title}</Link></td>
                  <td>{KINDS[p.kind]}{p.kind === "FORMATION" ? ` · ${p._count.lessons} leçons` : ""}</td>
                  <td>{fcfa(p.price)}</td>
                  <td>{p._count.orders}</td>
                  <td><span className={`status status-${p.status}`}>{ST[p.status]}</span></td>
                  <td>
                    <div className="row-actions">
                      <Link className="btn btn-outline btn-sm" href={`/vendeur/produits/${p.id}`}>Modifier</Link>
                      <form action={deleteProductAction}><input type="hidden" name="id" value={p.id} /><button className="btn btn-danger btn-sm">Supprimer</button></form>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </VendorShell>
  );
}

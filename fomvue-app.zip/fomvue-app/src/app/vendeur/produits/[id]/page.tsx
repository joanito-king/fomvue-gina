import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { requireCreator } from "@/lib/auth";
import { addLessonAction, deleteLessonAction } from "@/app/actions/vendor";
import { VendorShell } from "@/components/VendorShell";
import { ProductForm } from "@/components/ProductForm";

export const metadata = { title: "Modifier le produit" };

export default async function Page({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<Record<string, string | undefined>> }) {
  const { id } = await params;
  const sp = await searchParams;
  const { shop } = await requireCreator();
  const p = await prisma.product.findUnique({ where: { id }, include: { lessons: { orderBy: { position: "asc" } } } });
  if (!p || p.shopId !== shop.id) notFound();
  return (
    <VendorShell shop={shop} active="produits" sp={sp}>
      <h2 style={{ fontSize: "1.3rem", marginBottom: 12 }}>Modifier · {p.title}</h2>
      {p.status === "REJECTED" && <div className="alert alert-error">Ce produit a été refusé par la modération. Modifiez-le pour le soumettre à nouveau.</div>}
      <ProductForm p={p} />
      {p.kind === "FORMATION" && (
        <div className="panel" style={{ marginTop: 20 }}>
          <h2 style={{ fontSize: "1.25rem" }}>Leçons de la formation ({p.lessons.length})</h2>
          {p.lessons.length > 0 && (
            <table style={{ margin: "10px 0 16px" }}>
              <thead><tr><th>#</th><th>Module</th><th>Leçon</th><th>Durée</th><th></th></tr></thead>
              <tbody>
                {p.lessons.map((l, i) => (
                  <tr key={l.id}>
                    <td>{i + 1}</td><td>{l.section}</td><td>{l.title}{l.videoUrl ? " 🎬" : ""}</td><td>{l.durationMin} min</td>
                    <td><form action={deleteLessonAction}><input type="hidden" name="id" value={l.id} /><button className="btn btn-danger btn-sm">Retirer</button></form></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          <form action={addLessonAction}>
            <input type="hidden" name="productId" value={p.id} />
            <div className="form-grid">
              <div className="field"><label htmlFor="section">Module</label><input id="section" name="section" defaultValue={p.lessons.at(-1)?.section ?? "Module 1 · Les bases"} /></div>
              <div className="field"><label htmlFor="ltitle">Titre de la leçon</label><input id="ltitle" name="title" required /></div>
              <div className="field"><label htmlFor="videoUrl">Vidéo (lien YouTube ou MP4)</label><input id="videoUrl" name="videoUrl" type="url" placeholder="https://youtu.be/..." /></div>
              <div className="field"><label htmlFor="durationMin">Durée (min)</label><input id="durationMin" name="durationMin" type="number" min={1} defaultValue={8} /></div>
              <div className="field full"><label htmlFor="content">Contenu / notes</label><textarea id="content" name="content" /></div>
            </div>
            <button className="btn btn-teal" style={{ marginTop: 12 }}>Ajouter la leçon</button>
          </form>
        </div>
      )}
    </VendorShell>
  );
}

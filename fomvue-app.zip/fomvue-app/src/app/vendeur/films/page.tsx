import Link from "next/link";
import { prisma } from "@/lib/db";
import { requireCreator } from "@/lib/auth";
import { FILM_KINDS } from "@/lib/constants";
import { fcfa } from "@/lib/format";
import { createFilmAction, deleteFilmAction } from "@/app/actions/vendor";
import { VendorShell } from "@/components/VendorShell";
import { FilmAccessFields } from "@/components/FilmAccessFields";

export const metadata = { title: "Mes films" };

export default async function Page({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  const { shop } = await requireCreator();
  const films = await prisma.film.findMany({ where: { shopId: shop.id }, orderBy: { createdAt: "desc" }, include: { accesses: { select: { amount: true, commission: true, creatorNet: true, mode: true } } } });
  return (
    <VendorShell shop={shop} active="films" sp={sp}>
      <div className="panel">
        <h2 style={{ fontSize: "1.25rem", marginBottom: 8 }}>Mes titres dans Regarder</h2>
        {films.length === 0 ? (
          <p className="muted">Aucun titre publié.</p>
        ) : (
          <table>
            <thead><tr><th>Titre</th><th>Accès</th><th>Vues</th><th>Achats / locations</th><th>Brut</th><th>Commission</th><th>Vous touchez</th><th></th></tr></thead>
            <tbody>
              {films.map((f) => {
                const gross = f.accesses.reduce((s, a) => s + a.amount, 0);
                const fee = f.accesses.reduce((s, a) => s + a.commission, 0);
                return (
                  <tr key={f.id}>
                    <td><Link className="link-arrow" href={`/regarder/${f.id}`}>{f.title}</Link><div className="tiny">{FILM_KINDS[f.kind]}{f.status !== "PUBLISHED" ? " · archivé" : ""}</div></td>
                    <td>{f.access === "FREE" ? "Gratuit" : [f.buyPrice && `Achat ${fcfa(f.buyPrice)}`, f.rentPrice && `Loc. ${fcfa(f.rentPrice)}`].filter(Boolean).join(" · ")}</td>
                    <td>{f.views.toLocaleString("fr-FR")}</td>
                    <td>{f.accesses.filter((a) => a.mode === "BUY").length} / {f.accesses.filter((a) => a.mode === "RENT").length}</td>
                    <td>{fcfa(gross)}</td><td>{fcfa(fee)}</td><td><strong>{fcfa(gross - fee)}</strong></td>
                    <td><form action={deleteFilmAction}><input type="hidden" name="id" value={f.id} /><button className="btn btn-danger btn-sm">Retirer</button></form></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
      <form className="panel" action={createFilmAction} style={{ marginTop: 20 }}>
        <h2 style={{ fontSize: "1.25rem" }}>Publier un film ou une série</h2>
        <div className="form-grid">
          <div className="field"><label htmlFor="title">Titre</label><input id="title" name="title" required /></div>
          <div className="field"><label htmlFor="kind">Format</label><select id="kind" name="kind">{Object.entries(FILM_KINDS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></div>
          <div className="field full"><label htmlFor="synopsis">Synopsis</label><textarea id="synopsis" name="synopsis" required minLength={10} /></div>
          <div className="field full"><label htmlFor="videoUrl">Lien vidéo (YouTube, ou URL d’un fichier MP4)</label><input id="videoUrl" name="videoUrl" type="url" required placeholder="https://www.youtube.com/watch?v=..." /></div>
          <div className="field"><label htmlFor="durationLabel">Durée</label><input id="durationLabel" name="durationLabel" placeholder="Ex. 6 épisodes · 25 min" /></div>
          <div className="field"><label htmlFor="ageRating">Public</label><select id="ageRating" name="ageRating"><option>Tous publics</option><option>12+</option><option>16+</option></select></div>
          <div className="field full"><label htmlFor="poster">Affiche (facultatif)</label><input id="poster" name="poster" type="file" accept="image/*" /></div>
          <FilmAccessFields />
        </div>
        <button className="btn btn-primary btn-lg" style={{ marginTop: 16 }}>Publier dans Regarder</button>
      </form>
    </VendorShell>
  );
}

import { prisma } from "@/lib/db";
import { requireCreator } from "@/lib/auth";
import { MIN_PAYOUT } from "@/lib/constants";
import { dateFr, fcfa } from "@/lib/format";
import { shopBalance } from "@/lib/services/ledger";
import { payoutAction } from "@/app/actions/vendor";
import { VendorShell } from "@/components/VendorShell";

export const metadata = { title: "Espace vendeur" };

export default async function Page({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  const { shop } = await requireCreator();
  const since = new Date(Date.now() - 30 * 864e5);
  const [balance, orders30, earned, ledger, payouts, tipsSum] = await Promise.all([
    shopBalance(shop.id),
    prisma.order.count({ where: { shopId: shop.id, createdAt: { gte: since } } }),
    prisma.ledgerEntry.aggregate({ where: { shopId: shop.id, account: "CREATOR", type: { in: ["SALE", "FILM", "TIP"] } }, _sum: { amount: true } }),
    prisma.ledgerEntry.findMany({ where: { shopId: shop.id, account: "CREATOR" }, orderBy: { createdAt: "desc" }, take: 12 }),
    prisma.payout.findMany({ where: { shopId: shop.id }, orderBy: { createdAt: "desc" }, take: 6 }),
    prisma.tip.aggregate({ where: { shopId: shop.id }, _sum: { creatorNet: true } }),
  ]);
  const LABEL: Record<string, string> = { SALE: "Vente", FILM: "Film", TIP: "Soutien", PAYOUT: "Retrait", PAYOUT_REVERSAL: "Retrait annulé" };
  return (
    <VendorShell shop={shop} active="apercu" sp={sp}>
      <div className="dash-stats">
        <div className="stat"><div className="k">Ventes (30 jours)</div><div className="v">{orders30}</div></div>
        <div className="stat"><div className="k">Revenus nets (total)</div><div className="v" style={{ fontSize: "1.25rem" }}>{fcfa(earned._sum.amount ?? 0)}</div></div>
        <div className="stat"><div className="k">Solde à retirer</div><div className="v" style={{ fontSize: "1.25rem" }} data-testid="balance">{fcfa(balance)}</div></div>
        <div className="stat"><div className="k">Soutiens reçus (net)</div><div className="v" style={{ fontSize: "1.25rem" }}>{fcfa(tipsSum._sum.creatorNet ?? 0)}</div></div>
      </div>
      <div className="dash-grid">
        <div className="panel">
          <h2 style={{ fontSize: "1.25rem", marginBottom: 8 }}>Mouvements récents</h2>
          {ledger.length === 0 ? (
            <p className="muted">Aucune vente pour l’instant. Publiez un produit et partagez votre boutique !</p>
          ) : (
            <table>
              <thead><tr><th>Date</th><th>Type</th><th>Détail</th><th>Net</th></tr></thead>
              <tbody>
                {ledger.map((l) => (
                  <tr key={l.id}><td>{dateFr(l.createdAt)}</td><td>{LABEL[l.type] ?? l.type}</td><td>{l.label}</td><td style={{ color: l.amount < 0 ? "#8b1d12" : "var(--secondary)", fontWeight: 600 }}>{l.amount > 0 ? "+" : ""}{fcfa(l.amount)}</td></tr>
                ))}
              </tbody>
            </table>
          )}
          <p className="tiny" style={{ marginTop: 10 }}>Montants nets après commission Fomvue : 10 % sur ventes et titres payants, 5 % sur soutiens.</p>
        </div>
        <div className="panel">
          <h2 style={{ fontSize: "1.25rem", marginBottom: 8 }}>Retraits</h2>
          <p className="muted" style={{ marginBottom: 10 }}>Solde disponible : <strong>{fcfa(balance)}</strong> · minimum {fcfa(MIN_PAYOUT)}</p>
          <form action={payoutAction}>
            <div className="field"><label htmlFor="method">Moyen</label>
              <select id="method" name="method"><option value="wave">Wave</option><option value="orange">Orange Money</option><option value="mtn">MTN MoMo</option><option value="moov">Moov Money</option></select>
            </div>
            <div className="field"><label htmlFor="phone">Numéro</label><input id="phone" name="phone" type="tel" required placeholder="77 000 00 00" /></div>
            <div className="field"><label htmlFor="amount">Montant (F CFA)</label><input id="amount" name="amount" inputMode="numeric" required placeholder={String(MIN_PAYOUT)} /></div>
            <button className="btn btn-primary btn-block" style={{ marginTop: 14 }} disabled={balance < MIN_PAYOUT}>Demander un retrait</button>
          </form>
          {payouts.length > 0 && (
            <table style={{ marginTop: 16 }}>
              <thead><tr><th>Date</th><th>Montant</th><th>Statut</th></tr></thead>
              <tbody>{payouts.map((p) => <tr key={p.id}><td>{dateFr(p.createdAt)}</td><td>{fcfa(p.amount)}</td><td><span className={`status status-${p.status}`}>{p.status === "REQUESTED" ? "En attente" : p.status === "PAID" ? "Payé" : "Refusé"}</span></td></tr>)}</tbody>
            </table>
          )}
        </div>
      </div>
    </VendorShell>
  );
}

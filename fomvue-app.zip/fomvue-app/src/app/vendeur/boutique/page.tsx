import { requireCreator } from "@/lib/auth";
import { shopHost } from "@/lib/format";
import { updateShopAction } from "@/app/actions/vendor";
import { VendorShell } from "@/components/VendorShell";
import { ShopAvatar } from "@/components/Cards";

export const metadata = { title: "Ma boutique" };

export default async function Page({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  const { shop } = await requireCreator();
  return (
    <VendorShell shop={shop} active="boutique" sp={sp}>
      <form className="panel" action={updateShopAction}>
        <div style={{ display: "flex", gap: 14, alignItems: "center", marginBottom: 8 }}>
          <ShopAvatar shop={shop} size={64} />
          <div><strong>{shop.name}</strong><div className="shop-url">{shopHost(shop.slug)}</div></div>
        </div>
        <div className="form-grid">
          <div className="field"><label htmlFor="name">Nom de la boutique</label><input id="name" name="name" defaultValue={shop.name} required /></div>
          <div className="field"><label htmlFor="tagline">Accroche</label><input id="tagline" name="tagline" defaultValue={shop.tagline} maxLength={140} /></div>
          <div className="field full"><label htmlFor="bio">Présentation</label><textarea id="bio" name="bio" defaultValue={shop.bio} /></div>
          <div className="field"><label htmlFor="city">Ville</label><input id="city" name="city" defaultValue={shop.city} /></div>
          <div className="field"><label htmlFor="country">Pays</label><input id="country" name="country" defaultValue={shop.country} /></div>
          <div className="field"><label htmlFor="level">Niveau affiché</label><select id="level" name="level" defaultValue={shop.level}><option value="DEBUTANT">Débutant</option><option value="CONFIRME">Confirmé</option></select></div>
          <div className="field"><label htmlFor="color">Couleur de la boutique</label><input id="color" name="color" type="color" defaultValue={shop.color} style={{ height: 46 }} /></div>
          <div className="field full"><label htmlFor="logo">Logo (PNG, JPG, WEBP — 5 Mo max)</label><input id="logo" name="logo" type="file" accept="image/*" /></div>
        </div>
        <button className="btn btn-primary btn-lg" style={{ marginTop: 16 }}>Enregistrer</button>
      </form>
    </VendorShell>
  );
}

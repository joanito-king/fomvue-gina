import { prisma } from "@/lib/db";
import { requireCreator } from "@/lib/auth";
import { dateFr, fcfa } from "@/lib/format";
import { VendorShell } from "@/components/VendorShell";

export const metadata = { title: "Soutiens reçus" };

export default async function Page({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  const { shop } = await requireCreator();
  const tips = await prisma.tip.findMany({ where: { shopId: shop.id }, orderBy: { createdAt: "desc" } });
  const films = await prisma.film.findMany({ where: { id: { in: tips.map((t) => t.filmId).filter(Boolean) as string[] } }, select: { id: true, title: true } });
  const sum = (k: "amount" | "commission" | "creatorNet") => tips.reduce((s, t) => s + t[k], 0);
  return (
    <VendorShell shop={shop} active="soutiens" sp={sp}>
      <div className="dash-stats">
        <div className="stat"><div className="k">Soutiens</div><div className="v">{tips.length}</div></div>
        <div className="stat"><div className="k">Total brut</div><div className="v" style={{ fontSize: "1.25rem" }}>{fcfa(sum("amount"))}</div></div>
        <div className="stat"><div className="k">Commission (5 %)</div><div className="v" style={{ fontSize: "1.25rem" }}>{fcfa(sum("commission"))}</div></div>
        <div className="stat"><div className="k">Vous touchez</div><div className="v" style={{ fontSize: "1.25rem" }}>{fcfa(sum("creatorNet"))}</div></div>
      </div>
      <div className="panel">
        {tips.length === 0 ? <p className="muted">Pas encore de soutien. Le bouton « Soutenir le créateur » apparaît sur votre boutique, vos produits et vos films.</p> : (
          <table className="tips-table">
            <thead><tr><th>De</th><th>Message</th><th>Date</th><th>Origine</th><th>Montant</th><th>Net</th></tr></thead>
            <tbody>{tips.map((t) => (
              <tr key={t.id}><td>{t.senderName}</td><td>{t.message ?? "—"}</td><td>{dateFr(t.createdAt)}</td><td>{films.find((f) => f.id === t.filmId)?.title ?? "Boutique"}</td><td>{fcfa(t.amount)}</td><td><strong>{fcfa(t.creatorNet)}</strong></td></tr>
            ))}</tbody>
          </table>
        )}
      </div>
    </VendorShell>
  );
}
